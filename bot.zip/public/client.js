document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // --- DOM Elements ---
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    const saveConfigBtn = document.getElementById('saveConfigBtn');
    const botStatusEl = document.getElementById('botStatus');
    const logOutput = document.getElementById('log-output');
    const taskList = document.getElementById('taskList');
    const chatOutput = document.getElementById('chat-output');
    const chatInput = document.getElementById('chat-input');
    const inventoryGrid = document.getElementById('inventory-grid');
    const healthBar = document.getElementById('healthBar');
    const healthValue = document.getElementById('healthValue');
    const foodBar = document.getElementById('foodBar');
    const foodValue = document.getElementById('foodValue');

    // Config fields
    const host = document.getElementById('host');
    const port = document.getElementById('port');
    const username = document.getElementById('username');
    const authMode = document.getElementById('authMode');
    const password = document.getElementById('password');
    const isRegistered = document.getElementById('isRegistered');
    const loginTriggers = document.getElementById('loginTriggers');
    const autoEatEnabled = document.getElementById('autoEatEnabled');
    const autoEatFood = document.getElementById('autoEatFood');
    const autoTotemEnabled = document.getElementById('autoTotemEnabled');
    const autoLogEnabled = document.getElementById('autoLogEnabled');
    const autoLogHealth = document.getElementById('autoLogHealth');
    const webAuthEnabled = document.getElementById('webAuthEnabled');
    const webAuthUser = document.getElementById('webAuthUser');
    const webAuthPassword = document.getElementById('webAuthPassword');
    
    // --- Helper Functions ---
    function addLog(message) {
        logOutput.textContent += `[${new Date().toLocaleTimeString()}] ${message}\n`;
        logOutput.scrollTop = logOutput.scrollHeight; // Auto-scroll
    }

    function updateInventory(items) {
        inventoryGrid.innerHTML = ''; // 清空旧的背包显示
        const slots = new Array(36).fill(null); // 只显示主背包和快捷栏 (0-35)
        
        items.forEach(item => {
            if (item && item.slot >= 0 && item.slot <= 35) {
                slots[item.slot] = item;
            }
        });

        for (let i = 0; i < 36; i++) {
            const item = slots[i];
            const slotDiv = document.createElement('div');
            slotDiv.className = 'inventory-slot';

            if (item) {
                // 使用在线资源来显示物品图标，注意这依赖于外部服务
                const imageUrl = `https://raw.githubusercontent.com/PrismarineJS/minecraft-assets/master/data/1.16.4/items/${item.name}.png`;
                slotDiv.style.backgroundImage = `url('${imageUrl}')`;

                if (item.count > 1) {
                    const countSpan = document.createElement('span');
                    countSpan.className = 'item-count';
                    countSpan.textContent = item.count;
                    slotDiv.appendChild(countSpan);
                }
                
                const nameSpan = document.createElement('span');
                nameSpan.className = 'item-name';
                nameSpan.textContent = item.displayName;
                slotDiv.appendChild(nameSpan);
            }
            inventoryGrid.appendChild(slotDiv);
        }
    }

    function updateTaskList(task) {
        const placeholder = document.querySelector('.task-item-placeholder');
        if (placeholder) {
            placeholder.remove();
        }

        const taskItem = document.createElement('li');
        taskItem.className = 'task-item';
        taskItem.id = task.id;

        const mainContent = document.createElement('div');
        
        const taskName = document.createElement('span');
        taskName.className = 'task-name';
        taskName.textContent = task.name;
        mainContent.appendChild(taskName);

        if (task.details) {
            const taskDetails = document.createElement('span');
            taskDetails.className = 'task-details';
            taskDetails.textContent = `(${task.details})`;
            mainContent.appendChild(taskDetails);
        }

        const taskTime = document.createElement('span');
        taskTime.className = 'task-time';
        taskTime.textContent = task.time;

        taskItem.appendChild(mainContent);
        taskItem.appendChild(taskTime);

        // 将新任务添加到列表的顶部
        taskList.prepend(taskItem);
    }

    // --- Socket Event Listeners ---
    socket.on('connect', () => {
        addLog('已连接到后端服务器。');
    });

    socket.on('status', (message) => {
        addLog(message);
    });

    socket.on('bot_status', (status) => {
        botStatusEl.textContent = status === 'online' ? '在线' : '离线';
        botStatusEl.className = status;
    });

    socket.on('config', (config) => {
        // Server Config
        host.value = config.server.host;
        port.value = config.server.port;
        username.value = config.server.username;
        authMode.value = config.server.auth || 'offline';
        
        // Login Config
        password.value = config.login.password;
        isRegistered.checked = config.login.isRegistered;
        loginTriggers.value = config.login.loginTriggers.join(', ');

        // Auto Modules Config
        autoEatEnabled.checked = config.autoEat.enabled;
        autoEatFood.value = config.autoEat.food.join(', ');
        autoTotemEnabled.checked = config.autoTotem.enabled;
        autoLogEnabled.checked = config.autoLog.enabled;
        autoLogHealth.value = config.autoLog.healthThreshold;

        // Web Auth Config
        webAuthEnabled.checked = config.webAuth.enabled;
        webAuthUser.value = config.webAuth.user;
        webAuthPassword.value = config.webAuth.password;

        addLog('配置已加载。');
    });

    // 处理生命值和饥饿值更新
    socket.on('vitals', (data) => {
        healthBar.value = data.health;
        healthValue.textContent = `${Math.ceil(data.health)} / 20`;
        foodBar.value = data.food;
        foodValue.textContent = `${data.food} / 20`;
    });

    // 处理聊天消息
    socket.on('chat', (data) => {
        const chatLine = document.createElement('div');
        chatLine.textContent = data.formatted;
        chatOutput.appendChild(chatLine);
        chatOutput.scrollTop = chatOutput.scrollHeight;
    });

    // 处理背包更新
    socket.on('inventory', (items) => {
        updateInventory(items);
    });

    // 处理任务完成事件
    socket.on('task_completed', (task) => {
        updateTaskList(task);
    });

    // --- DOM Event Listeners ---
    startBtn.addEventListener('click', () => {
        socket.emit('start_bot');
    });

    stopBtn.addEventListener('click', () => {
        socket.emit('stop_bot');
    });

    saveConfigBtn.addEventListener('click', () => {
        const newConfig = {
            server: {
                host: host.value,
                port: parseInt(port.value, 10),
                username: username.value,
                auth: authMode.value
            },
            login: {
                password: password.value,
                isRegistered: isRegistered.checked,
                loginTriggers: loginTriggers.value.split(',').map(item => item.trim()).filter(Boolean)
            },
            autoEat: {
                enabled: autoEatEnabled.checked,
                food: autoEatFood.value.split(',').map(item => item.trim()).filter(Boolean)
            },
            autoTotem: {
                enabled: autoTotemEnabled.checked
            },
            autoLog: {
                enabled: autoLogEnabled.checked,
                healthThreshold: parseInt(autoLogHealth.value, 10)
            },
            webAuth: {
                enabled: webAuthEnabled.checked,
                user: webAuthUser.value,
                password: webAuthPassword.value
            }
        };
        socket.emit('update_config', newConfig);
    });

    // 处理聊天输入
    chatInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && chatInput.value.trim() !== '') {
            socket.emit('send_chat', chatInput.value);
            chatInput.value = ''; // 清空输入框
        }
    });

    // 初始化时清空背包显示
    updateInventory([]);
});
