const express = require('express');
const http = require('http');
const { Server } = require("socket.io");
const fs = require('fs');
const path = require('path');
const mineflayer = require('mineflayer');
const autoEat = require('mineflayer-auto-eat').plugin;
const pathfinderPkg = require('mineflayer-pathfinder');
const Movements = pathfinderPkg.Movements;
const basicAuth = require("express-basic-auth");

// --- Web 服务器设置 ---
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = 3000;

let bot = null;
let config = JSON.parse(fs.readFileSync('config.json'));

// 启用 Web 认证
if (config.webAuth && config.webAuth.enabled) {
    console.log("Web 密码保护已启用。");
    app.use(basicAuth({
        users: { [config.webAuth.user]: config.webAuth.password },
        challenge: true,
        unauthorizedResponse: '未经授权的访问！'
    }));
}

// 托管前端文件
app.use(express.static(path.join(__dirname, 'public'))); 

// --- 任务报告辅助函数 ---
function reportTaskCompletion(taskName, details = '') {
    const timestamp = new Date();
    io.emit('task_completed', {
        id: `task-${timestamp.getTime()}`,
        name: taskName,
        details: details,
        time: timestamp.toLocaleTimeString()
    });
}

// --- 机器人核心逻辑 ---
function startBot() {
    if (bot) {
        console.log('机器人已在运行中。');
        io.emit('status', '机器人已在运行中。');
        return;
    }

    const botOptions = {
        host: config.server.host,
        port: config.server.port,
        username: config.server.username,
        auth: config.server.auth
    };

    console.log(`正在以 ${botOptions.auth} 模式启动机器人...`);
    io.emit('status', `正在以 ${botOptions.auth} 模式启动机器人...`);

    try {
        bot = mineflayer.createBot(botOptions);
    } catch (error) {
        io.emit('status', `创建机器人实例失败: ${error.message}`);
        return;
    }

    // 加载插件
    bot.loadPlugin(autoEat);
    bot.loadPlugin(pathfinderPkg.pathfinder);

    // --- 智能登录逻辑 ---
    let loggedIn = false; 

    const onChatMessage = (jsonMsg) => {
        const message = jsonMsg.toString().trim();
        if (message === '') return;

        // 聊天转发
        io.emit('chat', { raw: jsonMsg.toAnsi(), formatted: message });
        io.emit('status', `[聊天] ${message}`); // 同时也发送到系统日志

        // 登录触发逻辑
        if (!loggedIn && config.login.loginTriggers.some(trigger => message.includes(trigger))) {
            io.emit('status', '检测到登录请求，正在静默发送密码...');
            
            const loginCommand = config.login.isRegistered 
                ? `login ${config.login.password}`
                : `register ${config.login.password} ${config.login.password}`;

            // 使用 sendCommand 静默执行
            bot.sendCommand(loginCommand).then(() => {
                io.emit('status', '登录/注册命令已发送。');
            }).catch(err => {
                io.emit('status', `登录/注册命令失败: ${err.message}`);
            });

            setTimeout(() => {
                loggedIn = true;
                reportTaskCompletion('发送登录命令', config.login.isRegistered ? '登录' : '注册');
            }, 2000);
        }
    };

    bot.on('message', onChatMessage);

    bot.on('login', () => {
        io.emit('status', '已成功连接到服务器，正在等待登录指令...');
    });

    bot.on('spawn', () => {
        io.emit('status', '机器人已进入服务器！');
        reportTaskCompletion('进入服务器', `当前世界: ${bot.world.name}`);
        loggedIn = false; // 重置登录状态，以应对BungeeCord跳转

        // 首次发送生命值和背包信息
        io.emit('vitals', {
            health: bot.health,
            food: bot.food,
            foodSaturation: bot.foodSaturation
        });
        io.emit('inventory', bot.inventory.items());
        
        // 配置 AutoEat
        if (config.autoEat.enabled) {
            bot.autoEat.options = {
                priority: 'foodPoints',
                startAt: 14,
                bannedFood: [],
                eatingTimeout: 3,
                // 仅吃配置文件中指定的食物
                food: config.autoEat.food.map(name => bot.registry.itemsByName[name]?.id).filter(id => id !== undefined)
            };
            io.emit('status', `AutoEat已启用，食物白名单: ${config.autoEat.food.join(', ')}`);
        }
    });

    // --- 自动化模块和状态监听 ---
    bot.on('health', () => {
        // 发送生命值和饥饿值
        io.emit('vitals', {
            health: bot.health,
            food: bot.food,
            foodSaturation: bot.foodSaturation
        });

        // AutoTotem 逻辑
        if (config.autoTotem.enabled) {
            const totem = bot.inventory.findInventoryItem(bot.registry.itemsByName.totem_of_undying?.id);
            // 检查副手槽位(45)是否为空或不是图腾
            if (totem && (!bot.inventory.slots[45] || bot.inventory.slots[45].type !== totem.type)) {
                bot.equip(totem, 'off-hand').then(() => {
                    reportTaskCompletion('自动装备图腾');
                }).catch(err => {
                    io.emit('status', `装备图腾失败: ${err.message}`);
                });
            }
        }

        // AutoLog 逻辑
        if (config.autoLog.enabled && bot.health <= config.autoLog.healthThreshold) {
            io.emit('status', `生命值过低 (${bot.health})，自动下线！`);
            reportTaskCompletion('自动下线', `生命值低于 ${config.autoLog.healthThreshold}`);
            stopBot();
        }
    });

    // AutoEat 任务报告
    bot.on('autoeat_finished', (item) => {
        reportTaskCompletion('自动进食', `食用了 ${item.displayName}`);
    });
    
    // 背包更新监听
    bot.inventory.on('updateSlot', (slot, oldItem, newItem) => {
        // 仅在主背包(0-35)或副手(45)更新时发送
        if (slot >= 0 && slot <= 35 || slot === 45) {
            io.emit('inventory', bot.inventory.items());
        }
    });

    bot.on('kicked', (reason) => {
        io.emit('status', `被踢出服务器: ${reason}`);
        reportTaskCompletion('连接断开', `原因: 被踢出`);
        stopBot();
    });

    bot.on('end', (reason) => {
        io.emit('status', `连接断开: ${reason}`);
        bot = null;
        io.emit('bot_status', 'offline');
        // 清理前端UI
        io.emit('vitals', { health: 20, food: 20, foodSaturation: 5 });
        io.emit('inventory', []);
    });

    bot.on('error', (err) => {
        io.emit('status', `发生错误: ${err.message}`);
        reportTaskCompletion('发生错误', err.message);
        stopBot();
    });
}

function stopBot() {
    if (bot) {
        bot.quit();
        bot = null;
        io.emit('status', '机器人已停止。');
        io.emit('bot_status', 'offline');
    } else {
        io.emit('status', '机器人未在运行。');
    }
}

// --- Socket.IO 通信 ---
io.on('connection', (socket) => {
    console.log('前端已连接');
    socket.emit('config', config);
    socket.emit('bot_status', bot ? 'online' : 'offline');

    if (bot) {
        socket.emit('vitals', { health: bot.health, food: bot.food, foodSaturation: bot.foodSaturation });
        socket.emit('inventory', bot.inventory.items());
    }

    socket.on('start_bot', () => {
        io.emit('status', '收到启动指令');
        startBot();
        io.emit('bot_status', 'online');
    });

    socket.on('stop_bot', () => {
        io.emit('status', '收到停止指令');
        stopBot();
    });

    socket.on('update_config', (newConfig) => {
        config = newConfig;
        fs.writeFileSync('config.json', JSON.stringify(config, null, 2));
        io.emit('config', config);
        io.emit('status', '配置已更新。如果机器人正在运行，请重启以应用所有更改。');
    });

    // 接收前端发送的聊天消息或命令
    socket.on('send_chat', (message) => {
        if (!bot) {
            socket.emit('status', '错误：机器人不在线，无法发送消息。');
            return;
        }

        if (message.startsWith('/')) {
            // 命令：使用 sendCommand 静默执行
            const command = message.substring(1);
            io.emit('status', `正在执行命令: /${command}`);
            bot.sendCommand(command).then(() => {
                reportTaskCompletion('执行命令', message);
            }).catch(err => {
                io.emit('status', `命令执行失败: ${err.message}`);
            });
        } else {
            // 聊天：使用 chat 发送到公屏
            bot.chat(message);
            reportTaskCompletion('发送聊天消息', message);
        }
    });
});

server.listen(PORT, () => {
    console.log(`Web界面已在 http://localhost:${PORT} 上运行`);
});
