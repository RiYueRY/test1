// Socket.IO 连接
const socket = io();

// DOM 元素
const startBotButton = document.getElementById('startBot');
const stopBotButton = document.getElementById('stopBot');
const botStatusDiv = document.getElementById('botStatus');
const logContainer = document.getElementById('logContainer');
const chatContainer = document.getElementById('chatContainer');
const commandInput = document.getElementById('commandInput');
const sendCommandButton = document.getElementById('sendCommand');
const healthValue = document.getElementById('healthValue');
const foodValue = document.getElementById('foodValue');

// 配置面板元素
const configToggle = document.getElementById('configToggle');
const configPanel = document.getElementById('configPanel');
const configForm = document.getElementById('configForm');
const configSave = document.getElementById('configSave');
const configCancel = document.getElementById('configCancel');
const configMessage = document.getElementById('configMessage');

// 配置表单字段
const configFields = {
    host: document.getElementById('configHost'),
    port: document.getElementById('configPort'),
    username: document.getElementById('configUsername'),
    auth: document.getElementById('configAuth'),
    password: document.getElementById('configPassword'),
    login_password: document.getElementById('configLoginPassword'),
    version: document.getElementById('configVersion'),
    auto_register: document.getElementById('configAutoRegister'),
    auto_login: document.getElementById('configAutoLogin')
};

// 最大日志条数，防止内存溢出
const MAX_LOGS = 500;
const MAX_CHATS = 300;

/**
 * 添加日志消息
 */
function addLog(type, message) {
    const p = document.createElement('p');
    p.className = `log-${type}`;
    p.textContent = `[${type.toUpperCase()}] ${message}`;
    logContainer.appendChild(p);

    // 限制日志条数
    if (logContainer.children.length > MAX_LOGS) {
        logContainer.removeChild(logContainer.firstChild);
    }

    // 自动滚动到底部
    logContainer.scrollTop = logContainer.scrollHeight;
}

/**
 * 添加聊天消息
 */
function addChat(message) {
    const div = document.createElement('div');
    div.className = 'chat-message';
    div.textContent = message;
    chatContainer.appendChild(div);

    // 限制聊天条数
    if (chatContainer.children.length > MAX_CHATS) {
        chatContainer.removeChild(chatContainer.firstChild);
    }

    // 自动滚动到底部
    chatContainer.scrollTop = chatContainer.scrollHeight;
}

/**
 * 更新机器人状态
 */
function updateBotStatus(status, message, health, food) {
    botStatusDiv.textContent = `机器人状态: ${status.toUpperCase()} (${message})`;
    botStatusDiv.className = `status-${status}`;

    // 更新生命值和饱食度
    if (health !== undefined) {
        healthValue.textContent = `${health.toFixed(1)} ❤️`;
    }
    if (food !== undefined) {
        foodValue.textContent = `${food} 🍗`;
    }

    // 更新按钮状态
    if (status === 'running') {
        startBotButton.disabled = true;
        stopBotButton.disabled = false;
        sendCommandButton.disabled = false;
    } else {
        startBotButton.disabled = false;
        stopBotButton.disabled = true;
        sendCommandButton.disabled = true;
        if (status === 'stopped') {
            healthValue.textContent = '--';
            foodValue.textContent = '--';
        }
    }
}

/**
 * 发送命令
 */
function sendCommand() {
    const command = commandInput.value.trim();
    if (command) {
        socket.emit('sendCommand', command);
        commandInput.value = '';
        commandInput.focus();
    }
}

/**
 * 加载配置到表单
 */
async function loadConfigToForm() {
    try {
        const response = await fetch('/api/config');
        if (!response.ok) throw new Error('加载配置失败');
        
        const config = await response.json();
        
        // 填充表单字段
        Object.keys(configFields).forEach(key => {
            if (configFields[key] && config[key] !== undefined) {
                configFields[key].value = config[key];
            }
        });

        addLog('info', '配置已加载');
    } catch (error) {
        addLog('error', `加载配置失败: ${error.message}`);
    }
}

/**
 * 保存配置
 */
async function saveConfig() {
    try {
        const config = {};
        Object.keys(configFields).forEach(key => {
            if (configFields[key]) {
                const value = configFields[key].value.trim();
                if (key === 'port') {
                    config[key] = parseInt(value) || 25565;
                } else {
                    config[key] = value;
                }
            }
        });

        // 验证必要字段
        if (!config.host || !config.port || !config.username) {
            showConfigMessage('缺少必要字段: 服务器地址、端口、用户名', 'error');
            return;
        }

        const response = await fetch('/api/config', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(config)
        });

        const result = await response.json();
        
        if (result.success) {
            showConfigMessage('配置已保存成功', 'success');
            addLog('info', '配置已保存');
        } else {
            showConfigMessage(result.message || '保存配置失败', 'error');
        }
    } catch (error) {
        showConfigMessage(`保存失败: ${error.message}`, 'error');
        addLog('error', `保存配置失败: ${error.message}`);
    }
}

/**
 * 显示配置消息
 */
function showConfigMessage(message, type) {
    configMessage.textContent = message;
    configMessage.className = `config-message ${type}`;
    
    // 3秒后自动隐藏
    setTimeout(() => {
        configMessage.className = 'config-message';
    }, 3000);
}

/**
 * 切换配置面板
 */
function toggleConfigPanel() {
    configPanel.classList.toggle('open');
    if (configPanel.classList.contains('open')) {
        loadConfigToForm();
    }
}

// 事件监听器
startBotButton.addEventListener('click', () => {
    socket.emit('startBot');
});

stopBotButton.addEventListener('click', () => {
    socket.emit('stopBot');
});

sendCommandButton.addEventListener('click', sendCommand);

commandInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendCommand();
    }
});

// 配置面板事件
configToggle.addEventListener('click', toggleConfigPanel);

configSave.addEventListener('click', saveConfig);

configCancel.addEventListener('click', () => {
    configPanel.classList.remove('open');
    configMessage.className = 'config-message';
});

// Socket.IO 事件处理

/**
 * 连接成功
 */
socket.on('connect', () => {
    addLog('info', '已连接到Web服务器');
});

/**
 * 断开连接
 */
socket.on('disconnect', () => {
    addLog('error', '与Web服务器断开连接');
    updateBotStatus('stopped', '连接已断开');
});

/**
 * 机器人状态更新
 */
socket.on('botStatus', (data) => {
    const { status, message, health, food } = data;
    updateBotStatus(status, message, health, food);
});

/**
 * 机器人日志
 */
socket.on('botLog', (data) => {
    const { type, message } = data;
    addLog(type, message);
});

/**
 * 服务器聊天消息
 */
socket.on('serverChat', (data) => {
    const { message } = data;
    addChat(message);
});

/**
 * 配置更新通知
 */
socket.on('configUpdated', (data) => {
    addLog('info', '配置已更新');
});

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    // 清空初始内容
    logContainer.innerHTML = '';
    chatContainer.innerHTML = '';

    // 添加初始化消息
    addLog('info', '页面已加载，等待连接...');
});
