const mineflayer = require('mineflayer');
const fs = require('fs');
const path = require('path');

const CONFIG_FILE = path.join(__dirname, 'config.json');

let config;
try {
    const configData = fs.readFileSync(CONFIG_FILE, 'utf8');
    config = JSON.parse(configData);
} catch (error) {
    console.error('无法读取或解析 config.json:', error.message);
    process.exit(1);
}

const botConfig = {
    host: config.host,
    port: config.port,
    username: config.username,
    password: config.password,
    auth: config.auth,
    version: config.version,
    // 确保离线模式下不发送密码
    ...((config.auth === 'mojang' || config.auth === 'microsoft') && { password: config.password })
};

let bot = null;
let isReconnecting = false;
let autoRejoinTimeout = null;

// 用于与server.js通信的函数
function sendToServer(type, data) {
    process.send({
        type: type,
        data: data
    });
}

function createBot() {
    console.log(`正在连接到服务器: ${botConfig.host}:${botConfig.port}`);
    sendToServer('log', { level: 'info', message: `正在连接到服务器: ${botConfig.host}:${botConfig.port}` });
    
    bot = mineflayer.createBot(botConfig);

    bot.on('login', () => {
        console.log(`[BOT] 成功登录! 用户名: ${bot.username}`);
        sendToServer('log', { level: 'info', message: `成功登录! 用户名: ${bot.username}` });
        isReconnecting = false;
        clearTimeout(autoRejoinTimeout);
    });

    bot.on('kicked', (reason, loggedIn) => {
        console.warn(`[BOT] 被踢出: ${reason}`);
        sendToServer('log', { level: 'warn', message: `被踢出: ${reason}` });
        if (config.auto_rejoin) {
            reconnect();
        }
    });

    bot.on('error', (err) => {
        console.error(`[BOT] 错误: ${err.message}`);
        sendToServer('log', { level: 'error', message: `错误: ${err.message}` });
        if (config.auto_rejoin) {
            reconnect();
        }
    });

    bot.on('end', (reason) => {
        console.log(`[BOT] 断开连接: ${reason}`);
        sendToServer('log', { level: 'info', message: `断开连接: ${reason}` });
        if (config.auto_rejoin && !isReconnecting) {
            reconnect();
        }
    });

    // 监听聊天消息
    bot.on('message', (jsonMsg, position) => {
        const message = jsonMsg.toAnsi();
        console.log(`[CHAT] ${message}`);
        sendToServer('chat', { message: message });
        
        // 登录插件处理
        if (message.includes('register') && message.includes(config.username) && config.auto_register) {
            console.log('[BOT] 尝试注册...');
            sendToServer('log', { level: 'info', message: '尝试注册...' });
            const registerCommand = config.auto_register.replace(/<password>/g, config.login_password);
            bot.chat(registerCommand);
        } else if (message.includes('login') && message.includes(config.username) && config.auto_login) {
            console.log('[BOT] 尝试登录...');
            sendToServer('log', { level: 'info', message: '尝试登录...' });
            const loginCommand = config.auto_login.replace(/<password>/g, config.login_password);
            bot.chat(loginCommand);
        }
    });

    // 监听玩家状态更新（生命值、饱食度等）
    bot.on('health', () => {
        const health = bot.health;
        const food = bot.food;
        console.log(`[STATUS] 生命值: ${health}, 饱食度: ${food}`);
        sendToServer('status', { health: health, food: food });
    });

    // 监听饱食度变化
    bot.on('foodLevelChange', () => {
        const health = bot.health;
        const food = bot.food;
        console.log(`[STATUS] 生命值: ${health}, 饱食度: ${food}`);
        sendToServer('status', { health: health, food: food });
    });

    // 每秒更新一次状态
    setInterval(() => {
        if (bot && bot.health !== undefined && bot.food !== undefined) {
            sendToServer('status', { health: bot.health, food: bot.food });
        }
    }, 1000);

    // 监听标准输入，以便server.js可以通过stdin发送命令
    process.stdin.on('data', (data) => {
        const command = data.toString().trim();
        if (command.startsWith('/')) {
            bot.chat(command);
            console.log(`[COMMAND] ${command}`);
            sendToServer('log', { level: 'command', message: command });
        } else {
            // 可以在这里处理一些内部命令，例如 'disconnect'
            if (command === 'disconnect') {
                bot.quit('Requested by Web Console');
            } else {
                bot.chat(command);
                console.log(`[COMMAND] ${command}`);
                sendToServer('log', { level: 'command', message: command });
            }
        }
    });
}

function reconnect() {
    if (isReconnecting) return;
    isReconnecting = true;
    console.log(`[BOT] 尝试在 ${config.rejoin_delay / 1000} 秒后重连...`);
    sendToServer('log', { level: 'info', message: `尝试在 ${config.rejoin_delay / 1000} 秒后重连...` });
    autoRejoinTimeout = setTimeout(() => {
        createBot();
    }, config.rejoin_delay);
}

// 首次运行，创建机器人
createBot();

// 保持进程运行，直到被父进程终止
process.on('SIGTERM', () => {
    console.log('[BOT] 收到终止信号，正在退出...');
    sendToServer('log', { level: 'info', message: '收到终止信号，正在退出...' });
    if (bot) {
        bot.quit('Web Console Shutdown');
    }
    process.exit(0);
});

// 处理来自server.js的消息
process.on('message', (msg) => {
    if (msg.type === 'chat') {
        if (bot) {
            bot.chat(msg.data);
            console.log(`[COMMAND] ${msg.data}`);
        }
    }
});
