const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const { spawn } = require('child_process');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

const PORT = 3000;
const BOT_SCRIPT = path.join(__dirname, 'bot.js');
const CONFIG_FILE = path.join(__dirname, 'config.json');

let botProcess = null;
let botStatus = 'stopped';

// 读取配置
let config = {};

function loadConfig() {
    try {
        const configData = fs.readFileSync(CONFIG_FILE, 'utf8');
        config = JSON.parse(configData);
        return true;
    } catch (error) {
        console.error('无法读取或解析 config.json:', error.message);
        return false;
    }
}

function saveConfig() {
    try {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 4), 'utf8');
        console.log('配置已保存');
        return true;
    } catch (error) {
        console.error('无法保存 config.json:', error.message);
        return false;
    }
}

// 初始化配置
if (!loadConfig()) {
    process.exit(1);
}

// 中间件
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

/**
 * 获取当前配置
 */
app.get('/api/config', (req, res) => {
    res.json(config);
});

/**
 * 更新配置
 */
app.post('/api/config', (req, res) => {
    const newConfig = req.body;
    
    // 验证必要字段
    if (!newConfig.host || !newConfig.port || !newConfig.username) {
        return res.status(400).json({ 
            success: false, 
            message: '缺少必要字段: host, port, username' 
        });
    }

    // 更新配置
    config = { ...config, ...newConfig };
    
    // 保存到文件
    if (saveConfig()) {
        io.emit('configUpdated', { config: config });
        res.json({ success: true, message: '配置已更新', config: config });
    } else {
        res.status(500).json({ success: false, message: '保存配置失败' });
    }
});

/**
 * 启动机器人进程
 */
function startBot() {
    if (botProcess) {
        console.log('机器人已在运行中。');
        return;
    }

    console.log('正在启动机器人...');
    botProcess = spawn('node', [BOT_SCRIPT], {
        stdio: ['pipe', 'pipe', 'pipe', 'ipc']
    });

    botStatus = 'running';
    io.emit('botStatus', { status: botStatus, message: '机器人已启动' });

    // 监听机器人进程的输出
    botProcess.stdout.on('data', (data) => {
        const msg = data.toString().trim();
        console.log(`[BOT-STDOUT]: ${msg}`);
        io.emit('botLog', { type: 'stdout', message: msg });
    });

    botProcess.stderr.on('data', (data) => {
        const msg = data.toString().trim();
        console.error(`[BOT-STDERR]: ${msg}`);
        io.emit('botLog', { type: 'stderr', message: msg });
    });

    // 监听来自机器人进程的IPC消息
    botProcess.on('message', (msg) => {
        if (msg.type === 'log') {
            const { level, message } = msg.data;
            console.log(`[BOT-${level.toUpperCase()}]: ${message}`);
            io.emit('botLog', { type: level, message: message });
        } else if (msg.type === 'chat') {
            const { message } = msg.data;
            console.log(`[CHAT]: ${message}`);
            io.emit('serverChat', { message: message });
        } else if (msg.type === 'status') {
            const { health, food } = msg.data;
            io.emit('botStatus', { status: botStatus, message: '机器人运行中', health: health, food: food });
        }
    });

    // 监听机器人进程退出
    botProcess.on('close', (code) => {
        console.log(`机器人进程退出，退出码: ${code}`);
        botProcess = null;
        botStatus = 'stopped';
        io.emit('botStatus', { status: botStatus, message: `机器人已停止, 退出码: ${code}` });
    });

    // 监听进程错误
    botProcess.on('error', (err) => {
        console.error('机器人进程启动失败或发生错误:', err);
        botProcess = null;
        botStatus = 'stopped';
        io.emit('botStatus', { status: botStatus, message: `机器人进程错误: ${err.message}` });
    });
}

/**
 * 停止机器人进程
 */
function stopBot() {
    if (botProcess) {
        console.log('正在停止机器人...');
        botProcess.kill('SIGTERM');
        botProcess = null;
        botStatus = 'stopping';
        io.emit('botStatus', { status: botStatus, message: '正在发送停止信号...' });
    } else {
        console.log('机器人未运行。');
        io.emit('botStatus', { status: botStatus, message: '机器人未运行' });
    }
}

// Socket.IO 连接
io.on('connection', (socket) => {
    console.log('一个新的Web客户端连接');

    // 发送当前机器人状态
    socket.emit('botStatus', { status: botStatus, message: `当前状态: ${botStatus}` });

    // 客户端请求启动机器人
    socket.on('startBot', () => {
        startBot();
    });

    // 客户端请求停止机器人
    socket.on('stopBot', () => {
        stopBot();
    });

    // 客户端请求发送命令
    socket.on('sendCommand', (command) => {
        if (botProcess && botStatus === 'running') {
            console.log(`[WEB-CMD]: ${command}`);
            botProcess.send({ type: 'chat', data: command });
            io.emit('botLog', { type: 'command', message: command });
        } else {
            socket.emit('botLog', { type: 'error', message: '机器人未运行，无法发送命令。' });
        }
    });

    socket.on('disconnect', () => {
        console.log('Web客户端断开连接');
    });
});

server.listen(PORT, () => {
    console.log(`Web服务器运行在 http://localhost:${PORT}`);
    console.log('请访问此地址来控制机器人。');
});
