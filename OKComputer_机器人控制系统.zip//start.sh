#!/bin/bash

# Mineflayer 机器人控制系统启动脚本

echo "🤖 Mineflayer 机器人控制系统"
echo "=============================="

# 检查Node.js是否安装
if ! command -v node &> /dev/null; then
    echo "❌ 错误: Node.js 未安装"
    echo "请先安装Node.js: https://nodejs.org/"
    exit 1
fi

# 检查npm是否安装
if ! command -v npm &> /dev/null; then
    echo "❌ 错误: npm 未安装"
    exit 1
fi

# 显示Node.js版本
NODE_VERSION=$(node --version)
echo "✅ Node.js 版本: $NODE_VERSION"

# 安装依赖
echo "📦 安装项目依赖..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ 依赖安装失败"
    exit 1
fi

echo "✅ 依赖安装完成"

# 检查环境文件
if [ ! -f .env ]; then
    echo "⚠️  未找到 .env 文件，创建默认配置..."
    cat > .env << EOF
PORT=3000
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
NODE_ENV=development

# Minecraft 服务器配置（可选）
ENABLE_BOT=false
MINECRAFT_HOST=localhost
MINECRAFT_PORT=25565
MINECRAFT_USERNAME=WebRobot
MINECRAFT_VERSION=1.20.1
EOF
    echo "✅ 默认配置文件已创建"
    echo "⚠️  请根据需要修改 .env 文件"
fi

# 显示使用说明
echo ""
echo "🚀 项目启动完成！"
echo "=============================="
echo "📱 访问地址: http://localhost:3000"
echo "👤 默认账号: admin"
echo "🔑 默认密码: password"
echo ""
echo "📋 可用命令:"
echo "  npm start    - 启动服务器"
echo "  npm run dev  - 开发模式启动"
echo ""
echo "🔧 配置文件:"
echo "  .env         - 环境变量配置"
echo "  server.js    - 主服务器文件"
echo "  bot.js       - Mineflayer机器人"
echo ""
echo "📁 前端文件位于: public/"
echo "📁 后端文件位于: 根目录"
echo ""
echo "📝 详细说明请查看 README.md"
echo "=============================="

# 询问是否启动服务器
echo ""
read -p "是否立即启动服务器? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "🚀 启动服务器..."
    npm start
else
    echo "✅ 项目已准备就绪，使用 'npm start' 启动服务器"
fi