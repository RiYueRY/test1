class RobotController {
    constructor() {
        this.socket = null;
        this.authToken = localStorage.getItem('authToken');
        this.currentUser = JSON.parse(localStorage.getItem('user') || '{}');
        this.presets = [];
        this.currentTask = null;
        this.logs = [];
        
        this.init();
    }

    init() {
        this.checkAuth();
        this.setupSocket();
        this.setupEventListeners();
        this.loadInitialData();
        this.updateUserInfo();
    }

    checkAuth() {
        if (!this.authToken) {
            window.location.href = '/login.html';
            return;
        }

        // 验证令牌
        fetch('/api/verify', {
            headers: {
                'Authorization': `Bearer ${this.authToken}`
            }
        })
        .then(response => {
            if (!response.ok) {
                this.logout();
            }
        })
        .catch(() => {
            this.logout();
        });
    }

    setupSocket() {
        this.socket = io();
        
        this.socket.on('connect', () => {
            this.addLog('系统', '实时连接已建立', 'info');
        });

        this.socket.on('botStatusUpdated', (status) => {
            this.updateBotStatus(status);
        });

        this.socket.on('presetsUpdated', (presets) => {
            this.presets = presets;
            this.updatePresetsUI();
        });

        this.socket.on('taskStarted', (task) => {
            this.currentTask = task;
            this.updateTaskStatus();
            this.addLog('任务', `新任务已开始 - 目标: ${task.trapdoor.name}`, 'success');
        });

        this.socket.on('taskStopped', (task) => {
            this.currentTask = null;
            this.updateTaskStatus();
            this.addLog('任务', '任务已停止', 'warning');
        });

        this.socket.on('disconnect', () => {
            this.addLog('系统', '实时连接已断开', 'error');
        });
    }

    setupEventListeners() {
        // 导航
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.dataset.page;
                this.switchPage(page);
            });
        });

        // 任务控制
        document.getElementById('startTaskBtn').addEventListener('click', () => {
            this.startTask();
        });

        document.getElementById('stopTaskBtn').addEventListener('click', () => {
            this.stopTask();
        });

        // 预设点管理
        document.getElementById('addPresetBtn').addEventListener('click', () => {
            this.showPresetModal();
        });

        document.getElementById('cancelPresetBtn').addEventListener('click', () => {
            this.hidePresetModal();
        });

        document.getElementById('presetForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addPreset();
        });

        // 日志
        document.getElementById('clearLogBtn').addEventListener('click', () => {
            this.clearLogs();
        });

        // 退出登录
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.logout();
        });
    }

    async loadInitialData() {
        try {
            // 加载机器人状态
            const statusResponse = await fetch('/api/bot-status', {
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });
            
            if (statusResponse.ok) {
                const status = await statusResponse.json();
                this.updateBotStatus(status);
            }

            // 加载预设点
            await this.loadPresets();
        } catch (error) {
            console.error('加载初始数据失败:', error);
            this.addLog('错误', '加载数据失败', 'error');
        }
    }

    async loadPresets() {
        try {
            const response = await fetch('/api/presets', {
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });
            
            if (response.ok) {
                this.presets = await response.json();
                this.updatePresetsUI();
            }
        } catch (error) {
            console.error('加载预设点失败:', error);
        }
    }

    updateBotStatus(status) {
        // 更新连接状态
        const statusIndicator = document.getElementById('connectionStatus');
        const connectionText = document.getElementById('connectionText');
        const botConnectionStatus = document.getElementById('botConnectionStatus');
        
        if (status.connected) {
            statusIndicator.className = 'status-indicator status-connected';
            connectionText.textContent = '已连接';
            botConnectionStatus.textContent = '在线';
            botConnectionStatus.className = 'text-green-400';
        } else {
            statusIndicator.className = 'status-indicator status-disconnected';
            connectionText.textContent = '断开连接';
            botConnectionStatus.textContent = '离线';
            botConnectionStatus.className = 'text-red-400';
        }

        // 更新位置
        document.getElementById('botPosition').textContent = 
            `X:${Math.round(status.position.x)} Y:${Math.round(status.position.y)} Z:${Math.round(status.position.z)}`;

        // 更新生命值
        const healthPercent = (status.health / 20) * 100;
        document.getElementById('healthBar').style.width = `${healthPercent}%`;
        document.getElementById('healthText').textContent = `${Math.round(status.health)}/20`;

        // 更新饥饿值
        const foodPercent = (status.food / 20) * 100;
        document.getElementById('foodBar').style.width = `${foodPercent}%`;
        document.getElementById('foodText').textContent = `${Math.round(status.food)}/20`;

        // 更新当前任务
        this.currentTask = status.currentTask;
        this.updateTaskStatus();
    }

    updateTaskStatus() {
        const taskStatus = document.getElementById('taskStatus');
        
        if (this.currentTask && this.currentTask.status === 'running') {
            const progress = this.calculateTaskProgress();
            taskStatus.innerHTML = `
                <div class="text-center">
                    <div class="w-16 h-16 bg-orange-500 rounded-full mx-auto mb-4 flex items-center justify-center animate-spin">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                        </svg>
                    </div>
                    <p class="text-white font-medium mb-2">任务执行中</p>
                    <p class="text-gray-400 text-sm mb-3">前往: ${this.currentTask.trapdoor.name}</p>
                    <div class="w-full bg-gray-700 rounded-full h-2 mb-2">
                        <div class="progress-bar rounded-full h-2" style="width: ${progress}%"></div>
                    </div>
                    <p class="text-xs text-gray-500">进度: ${progress}%</p>
                </div>
            `;
            
            document.getElementById('startTaskBtn').disabled = true;
            document.getElementById('stopTaskBtn').disabled = false;
        } else {
            taskStatus.innerHTML = `
                <div class="text-center">
                    <div class="w-16 h-16 bg-gray-700 rounded-full mx-auto mb-4 flex items-center justify-center">
                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <p class="text-gray-400">暂无正在执行的任务</p>
                </div>
            `;
            
            document.getElementById('startTaskBtn').disabled = false;
            document.getElementById('stopTaskBtn').disabled = true;
        }
    }

    calculateTaskProgress() {
        if (!this.currentTask) return 0;
        
        const elapsed = Date.now() - new Date(this.currentTask.startedAt).getTime();
        const estimatedDuration = 60000; // 假设任务需要60秒
        const progress = Math.min(100, (elapsed / estimatedDuration) * 100);
        
        return Math.round(progress);
    }

    updatePresetsUI() {
        // 更新下拉菜单
        const trapdoorSelect = document.getElementById('trapdoorSelect');
        const standbySelect = document.getElementById('standbySelect');
        
        trapdoorSelect.innerHTML = '<option value="">选择活板门...</option>';
        standbySelect.innerHTML = '<option value="">选择待机点...</option>';
        
        this.presets.forEach(preset => {
            const option = document.createElement('option');
            option.value = preset.id;
            option.textContent = `${preset.name} (${preset.x}, ${preset.y}, ${preset.z})`;
            
            if (preset.type === 'trapdoor') {
                trapdoorSelect.appendChild(option);
            } else if (preset.type === 'standby') {
                standbySelect.appendChild(option);
            }
        });

        // 更新预设点网格
        this.updatePresetsGrid();
    }

    updatePresetsGrid() {
        const grid = document.getElementById('presetsGrid');
        
        if (this.presets.length === 0) {
            grid.innerHTML = `
                <div class="col-span-full text-center py-12">
                    <div class="w-16 h-16 bg-gray-700 rounded-full mx-auto mb-4 flex items-center justify-center">
                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                        </svg>
                    </div>
                    <p class="text-gray-400">暂无预设点</p>
                    <p class="text-gray-500 text-sm mt-2">点击"添加预设点"按钮创建新的预设点</p>
                </div>
            `;
            return;
        }
        
        grid.innerHTML = this.presets.map(preset => `
            <div class="preset-card glass-panel rounded-xl p-6">
                <div class="flex items-center justify-between mb-4">
                    <h4 class="text-lg font-semibold text-white">${preset.name}</h4>
                    <span class="px-2 py-1 text-xs rounded-full ${preset.type === 'trapdoor' ? 'bg-orange-600/20 text-orange-400' : 'bg-blue-600/20 text-blue-400'}">
                        ${preset.type === 'trapdoor' ? '活板门' : '待机点'}
                    </span>
                </div>
                <div class="space-y-2 mb-4">
                    <div class="flex justify-between">
                        <span class="text-gray-400">坐标</span>
                        <span class="text-white">${preset.x}, ${preset.y}, ${preset.z}</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-400">ID</span>
                        <span class="text-gray-500 text-sm">${preset.id.substring(0, 8)}...</span>
                    </div>
                </div>
                <div class="flex space-x-2">
                    <button onclick="robotController.editPreset('${preset.id}')" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded text-sm font-medium transition-colors">
                        编辑
                    </button>
                    <button onclick="robotController.deletePreset('${preset.id}')" class="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-3 rounded text-sm font-medium transition-colors">
                        删除
                    </button>
                </div>
            </div>
        `).join('');
    }

    async startTask() {
        const trapdoorId = document.getElementById('trapdoorSelect').value;
        const standbyId = document.getElementById('standbySelect').value;
        
        if (!trapdoorId || !standbyId) {
            this.addLog('错误', '请选择目标活板门和待机点', 'error');
            return;
        }

        try {
            const response = await fetch('/api/task/start', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.authToken}`
                },
                body: JSON.stringify({ trapdoorId, standbyId })
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('任务', '任务启动成功', 'success');
            } else {
                this.addLog('错误', result.error || '任务启动失败', 'error');
            }
        } catch (error) {
            console.error('启动任务失败:', error);
            this.addLog('错误', '网络错误，任务启动失败', 'error');
        }
    }

    async stopTask() {
        try {
            const response = await fetch('/api/task/stop', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('任务', '任务已停止', 'warning');
            } else {
                this.addLog('错误', result.error || '停止任务失败', 'error');
            }
        } catch (error) {
            console.error('停止任务失败:', error);
            this.addLog('错误', '网络错误，停止任务失败', 'error');
        }
    }

    showPresetModal() {
        document.getElementById('presetModal').classList.remove('hidden');
        document.getElementById('presetModal').classList.add('flex');
        
        // 清空表单
        document.getElementById('presetForm').reset();
    }

    hidePresetModal() {
        document.getElementById('presetModal').classList.add('hidden');
        document.getElementById('presetModal').classList.remove('flex');
    }

    async addPreset() {
        const name = document.getElementById('presetName').value.trim();
        const x = parseInt(document.getElementById('presetX').value);
        const y = parseInt(document.getElementById('presetY').value);
        const z = parseInt(document.getElementById('presetZ').value);
        const type = document.getElementById('presetType').value;

        if (!name || isNaN(x) || isNaN(y) || isNaN(z)) {
            this.addLog('错误', '请填写所有必填字段', 'error');
            return;
        }

        try {
            const response = await fetch('/api/presets', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.authToken}`
                },
                body: JSON.stringify({ name, x, y, z, type })
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('预设点', `预设点 "${name}" 添加成功`, 'success');
                this.hidePresetModal();
                await this.loadPresets();
            } else {
                this.addLog('错误', result.error || '添加预设点失败', 'error');
            }
        } catch (error) {
            console.error('添加预设点失败:', error);
            this.addLog('错误', '网络错误，添加预设点失败', 'error');
        }
    }

    async deletePreset(id) {
        if (!confirm('确定要删除这个预设点吗？')) {
            return;
        }

        try {
            const response = await fetch(`/api/presets/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('预设点', '预设点删除成功', 'success');
                await this.loadPresets();
            } else {
                this.addLog('错误', result.error || '删除预设点失败', 'error');
            }
        } catch (error) {
            console.error('删除预设点失败:', error);
            this.addLog('错误', '网络错误，删除预设点失败', 'error');
        }
    }

    editPreset(id) {
        // 这里可以实现编辑功能，为了简化，暂时显示提示
        this.addLog('提示', '编辑功能开发中...', 'info');
    }

    switchPage(page) {
        // 更新导航状态
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-page="${page}"]`).classList.add('active');

        // 显示对应页面
        document.querySelectorAll('.page-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(`${page}Page`).classList.remove('hidden');
    }

    addLog(source, message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const logEntry = {
            source,
            message,
            type,
            timestamp
        };

        this.logs.push(logEntry);
        
        // 限制日志数量
        if (this.logs.length > 100) {
            this.logs.shift();
        }

        this.renderLog(logEntry);
    }

    renderLog(logEntry) {
        const container = document.getElementById('logContainer');
        const colors = {
            info: 'text-blue-400',
            success: 'text-green-400',
            warning: 'text-yellow-400',
            error: 'text-red-400'
        };

        const logElement = document.createElement('div');
        logElement.className = 'log-entry';
        logElement.innerHTML = `
            <span class="text-gray-400">[${logEntry.source}]</span>
            <span class="text-white ml-2">${logEntry.message}</span>
            <span class="${colors[logEntry.type]} text-xs ml-2">[${logEntry.timestamp}]</span>
        `;

        container.appendChild(logElement);
        
        // 自动滚动到底部
        container.scrollTop = container.scrollHeight;
    }

    clearLogs() {
        this.logs = [];
        document.getElementById('logContainer').innerHTML = '';
        this.addLog('系统', '日志已清除', 'info');
    }

    updateUserInfo() {
        document.getElementById('currentUser').textContent = this.currentUser.username || 'Unknown';
    }

    logout() {
        localStorage.clear();
        window.location.href = '/login.html';
    }
}

// 初始化控制器
let robotController;

document.addEventListener('DOMContentLoaded', () => {
    robotController = new RobotController();
    
    // 页面加载动画
    anime({
        targets: '.glass-panel',
        translateY: [20, 0],
        opacity: [0, 1],
        duration: 600,
        delay: anime.stagger(100),
        easing: 'easeOutQuad'
    });
});