class EnhancedRobotController {
    constructor() {
        this.socket = null;
        this.authToken = localStorage.getItem('authToken');
        this.currentUser = JSON.parse(localStorage.getItem('user') || '{}');
        this.config = null;
        this.presets = { standbyPoints: [], trapdoorPoints: [] };
        this.currentTask = null;
        this.logs = [];
        this.users = [];
        
        this.init();
    }

    init() {
        this.checkAuth();
        this.setupSocket();
        this.setupEventListeners();
        this.loadInitialData();
        this.updateUserInfo();
        this.startPeriodicUpdates();
    }

    checkAuth() {
        if (!this.authToken) {
            window.location.href = '/login.html';
            return;
        }

        // 验证令牌
        fetch('/api/verify', {
            headers: {
                'Authorization': `Bearer ${this.authToken}`
            }
        })
        .then(response => {
            if (!response.ok) {
                this.logout();
            }
        })
        .catch(() => {
            this.logout();
        });
    }

    setupSocket() {
        this.socket = io();
        
        this.socket.on('connect', () => {
            this.addLog('系统', '实时连接已建立', 'info');
        });

        this.socket.on('botStatusUpdated', (status) => {
            this.updateBotStatus(status);
        });

        this.socket.on('presetsUpdated', (presets) => {
            this.presets = presets;
            this.updatePresetsUI();
        });

        this.socket.on('configUpdated', (config) => {
            this.config = config;
            this.updateConfigUI();
        });

        this.socket.on('taskStarted', (task) => {
            this.currentTask = task;
            this.updateTaskStatus();
            this.addLog('任务', `新任务已开始 - 目标: ${task.trapdoor.name}`, 'success');
        });

        this.socket.on('taskStopped', (task) => {
            this.currentTask = null;
            this.updateTaskStatus();
            this.addLog('任务', '任务已停止', 'warning');
        });

        this.socket.on('disconnect', () => {
            this.addLog('系统', '实时连接已断开', 'error');
        });
    }

    setupEventListeners() {
        // 导航
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.dataset.page;
                this.switchPage(page);
            });
        });

        // 机器人连接控制
        document.getElementById('connectBotBtn').addEventListener('click', () => {
            this.connectBot();
        });

        document.getElementById('disconnectBotBtn').addEventListener('click', () => {
            this.disconnectBot();
        });

        document.getElementById('testConnectionBtn').addEventListener('click', () => {
            this.testConnection();
        });

        // 任务控制
        document.getElementById('startTaskBtn').addEventListener('click', () => {
            this.startTask();
        });

        document.getElementById('stopTaskBtn').addEventListener('click', () => {
            this.stopTask();
        });

        // 预设点管理
        document.getElementById('addStandbyBtn').addEventListener('click', () => {
            this.showPresetModal('standby');
        });

        document.getElementById('addTrapdoorBtn').addEventListener('click', () => {
            this.showPresetModal('trapdoor');
        });

        document.getElementById('cancelPresetBtn').addEventListener('click', () => {
            this.hidePresetModal();
        });

        document.getElementById('presetForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.savePreset();
        });

        // 配置管理
        document.getElementById('configForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveConfig();
        });

        document.getElementById('resetConfigBtn').addEventListener('click', () => {
            this.resetConfig();
        });

        document.getElementById('backupConfigBtn').addEventListener('click', () => {
            this.backupConfig();
        });

        document.getElementById('enableLoginCommands').addEventListener('change', (e) => {
            document.getElementById('loginCommandsSection').classList.toggle('hidden', !e.target.checked);
        });

        // 用户管理
        document.getElementById('addUserBtn').addEventListener('click', () => {
            this.showUserModal();
        });

        document.getElementById('cancelUserBtn').addEventListener('click', () => {
            this.hideUserModal();
        });

        document.getElementById('userForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addUser();
        });

        document.getElementById('cancelPasswordBtn').addEventListener('click', () => {
            this.hidePasswordModal();
        });

        document.getElementById('passwordForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.changePassword();
        });

        // 日志管理
        document.getElementById('clearLogBtn').addEventListener('click', () => {
            this.clearLogs();
        });

        document.getElementById('exportLogBtn').addEventListener('click', () => {
            this.exportLogs();
        });

        // 退出登录
        document.getElementById('logoutBtn').addEventListener('click', () => {
            this.logout();
        });
    }

    async loadInitialData() {
        try {
            // 加载系统状态
            const response = await fetch('/api/system-status', {
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                this.config = data.config;
                this.updateBotStatus(data.bot);
                this.updateConfigUI();
                
                // 更新连接控制表单的值
                if (this.config.minecraft) {
                    document.getElementById('serverHost').value = this.config.minecraft.host || 'localhost';
                    document.getElementById('serverPort').value = this.config.minecraft.port || 25565;
                    document.getElementById('botUsername').value = this.config.minecraft.username || 'WebRobot';
                    document.getElementById('minecraftVersion').value = this.config.minecraft.version || '1.20.1';
                }
            }

            // 加载预设点
            await this.loadPresets();

            // 加载用户列表（如果是管理员）
            if (this.currentUser.role === 'admin') {
                await this.loadUsers();
            }
        } catch (error) {
            console.error('加载初始数据失败:', error);
            this.addLog('错误', '加载数据失败', 'error');
        }
    }

    async loadPresets() {
        try {
            const response = await fetch('/api/presets', {
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });
            
            if (response.ok) {
                this.presets = await response.json();
                this.updatePresetsUI();
            }
        } catch (error) {
            console.error('加载预设点失败:', error);
        }
    }

    async loadUsers() {
        try {
            const response = await fetch('/api/users', {
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });
            
            if (response.ok) {
                this.users = await response.json();
                this.updateUsersTable();
            }
        } catch (error) {
            console.error('加载用户列表失败:', error);
        }
    }

    updateBotStatus(status) {
        // 更新连接状态
        const statusIndicator = document.getElementById('connectionStatus');
        const connectionText = document.getElementById('connectionText');
        const botConnectionStatus = document.getElementById('botConnectionStatus');
        const reconnectIndicator = document.getElementById('reconnectIndicator');
        const reconnectCount = document.getElementById('reconnectCount');
        
        if (status.connected) {
            statusIndicator.className = 'status-indicator status-connected';
            connectionText.textContent = '已连接';
            botConnectionStatus.textContent = '在线';
            botConnectionStatus.className = 'text-green-400';
            reconnectIndicator.classList.add('hidden');
            
            document.getElementById('connectBotBtn').disabled = true;
            document.getElementById('disconnectBotBtn').disabled = false;
        } else if (status.isConnecting) {
            statusIndicator.className = 'status-indicator status-connecting';
            connectionText.textContent = '连接中...';
            botConnectionStatus.textContent = '连接中';
            botConnectionStatus.className = 'text-yellow-400';
            reconnectIndicator.classList.remove('hidden');
        } else {
            statusIndicator.className = 'status-indicator status-disconnected';
            connectionText.textContent = '断开连接';
            botConnectionStatus.textContent = '离线';
            botConnectionStatus.className = 'text-red-400';
            reconnectIndicator.classList.add('hidden');
            
            document.getElementById('connectBotBtn').disabled = false;
            document.getElementById('disconnectBotBtn').disabled = true;
        }

        // 更新重连次数
        if (status.reconnectAttempts !== undefined) {
            reconnectCount.textContent = status.reconnectAttempts;
        }

        // 更新位置
        document.getElementById('botPosition').textContent = 
            `X:${Math.round(status.position.x)} Y:${Math.round(status.position.y)} Z:${Math.round(status.position.z)}`;

        // 更新生命值
        const healthPercent = (status.health / 20) * 100;
        document.getElementById('healthBar').style.width = `${healthPercent}%`;
        document.getElementById('healthText').textContent = `${Math.round(status.health)}/20`;

        // 更新饥饿值
        const foodPercent = (status.food / 20) * 100;
        document.getElementById('foodBar').style.width = `${foodPercent}%`;
        document.getElementById('foodText').textContent = `${Math.round(status.food)}/20`;

        // 更新当前任务
        this.currentTask = status.currentTask;
        this.updateTaskStatus();
    }

    updateTaskStatus() {
        const taskStatus = document.getElementById('taskStatus');
        
        if (this.currentTask && this.currentTask.status === 'running') {
            const progress = this.calculateTaskProgress();
            const currentStep = this.currentTask.steps.find(step => step.status === 'running');
            
            taskStatus.innerHTML = `
                <div class="text-center">
                    <div class="w-16 h-16 bg-orange-500 rounded-full mx-auto mb-4 flex items-center justify-center animate-spin">
                        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path>
                        </svg>
                    </div>
                    <p class="text-white font-medium mb-2">任务执行中</p>
                    <p class="text-gray-400 text-sm mb-2">当前步骤: ${currentStep ? currentStep.name : '准备中'}</p>
                    <p class="text-gray-400 text-sm mb-3">目标: ${this.currentTask.trapdoor.name}</p>
                    <div class="w-full bg-gray-700 rounded-full h-2 mb-2">
                        <div class="progress-bar rounded-full h-2" style="width: ${progress}%"></div>
                    </div>
                    <p class="text-xs text-gray-500">进度: ${progress}%</p>
                    <div class="mt-3">
                        <div class="text-xs text-gray-400">
                            ${this.currentTask.steps.map(step => 
                                `<span class="${step.status === 'completed' ? 'text-green-400' : step.status === 'running' ? 'text-orange-400' : 'text-gray-500'}">${step.name}</span>`
                            ).join(' → ')}
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('startTaskBtn').disabled = true;
            document.getElementById('stopTaskBtn').disabled = false;
        } else {
            taskStatus.innerHTML = `
                <div class="text-center">
                    <div class="w-16 h-16 bg-gray-700 rounded-full mx-auto mb-4 flex items-center justify-center">
                        <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                    </div>
                    <p class="text-gray-400">暂无正在执行的任务</p>
                </div>
            `;
            
            document.getElementById('startTaskBtn').disabled = false;
            document.getElementById('stopTaskBtn').disabled = true;
        }
    }

    calculateTaskProgress() {
        if (!this.currentTask) return 0;
        
        const elapsed = Date.now() - new Date(this.currentTask.startedAt).getTime();
        const estimatedDuration = 180000; // 假设任务需要3分钟
        const progress = Math.min(100, (elapsed / estimatedDuration) * 100);
        
        return Math.round(progress);
    }

    updatePresetsUI() {
        // 更新下拉菜单
        const trapdoorSelect = document.getElementById('trapdoorSelect');
        const standbySelect = document.getElementById('standbySelect');
        
        trapdoorSelect.innerHTML = '<option value="">选择活板门...</option>';
        standbySelect.innerHTML = '<option value="">选择待机点...</option>';
        
        this.presets.trapdoorPoints.forEach(preset => {
            const option = document.createElement('option');
            option.value = preset.id;
            option.textContent = `${preset.name} (${preset.x}, ${preset.y}, ${preset.z})`;
            trapdoorSelect.appendChild(option);
        });
        
        this.presets.standbyPoints.forEach(preset => {
            const option = document.createElement('option');
            option.value = preset.id;
            option.textContent = `${preset.name} (${preset.x}, ${preset.y}, ${preset.z})`;
            standbySelect.appendChild(option);
        });

        // 更新预设点网格
        this.updatePresetsGrid();
    }

    updatePresetsGrid() {
        const standbyGrid = document.getElementById('standbyPointsGrid');
        const trapdoorGrid = document.getElementById('trapdoorPointsGrid');
        
        // 更新待机点网格
        if (this.presets.standbyPoints.length === 0) {
            standbyGrid.innerHTML = `
                <div class="col-span-full text-center py-8">
                    <div class="text-gray-400">暂无待机点</div>
                    <div class="text-gray-500 text-sm mt-2">点击"添加待机点"按钮创建新的待机点</div>
                </div>
            `;
        } else {
            standbyGrid.innerHTML = this.presets.standbyPoints.map(preset => `
                <div class="preset-card glass-panel rounded-xl p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h4 class="text-lg font-semibold text-white">${preset.name}</h4>
                        <span class="px-2 py-1 text-xs rounded-full bg-blue-600/20 text-blue-400">待机点</span>
                    </div>
                    <div class="space-y-2 mb-4">
                        <div class="flex justify-between">
                            <span class="text-gray-400">坐标</span>
                            <span class="text-white">${preset.x}, ${preset.y}, ${preset.z}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-400">ID</span>
                            <span class="text-gray-500 text-sm">${preset.id.substring(0, 8)}...</span>
                        </div>
                        ${preset.description ? `
                        <div class="flex justify-between">
                            <span class="text-gray-400">描述</span>
                            <span class="text-gray-300 text-sm">${preset.description}</span>
                        </div>
                        ` : ''}
                    </div>
                    <div class="flex space-x-2">
                        <button onclick="robotController.editPreset('standby', '${preset.id}')" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded text-sm font-medium transition-colors">
                            编辑
                        </button>
                        <button onclick="robotController.deletePreset('standby', '${preset.id}')" class="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-3 rounded text-sm font-medium transition-colors">
                            删除
                        </button>
                    </div>
                </div>
            `).join('');
        }

        // 更新活板门网格
        if (this.presets.trapdoorPoints.length === 0) {
            trapdoorGrid.innerHTML = `
                <div class="col-span-full text-center py-8">
                    <div class="text-gray-400">暂无活板门</div>
                    <div class="text-gray-500 text-sm mt-2">点击"添加活板门"按钮创建新的活板门</div>
                </div>
            `;
        } else {
            trapdoorGrid.innerHTML = this.presets.trapdoorPoints.map(preset => `
                <div class="preset-card glass-panel rounded-xl p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h4 class="text-lg font-semibold text-white">${preset.name}</h4>
                        <span class="px-2 py-1 text-xs rounded-full bg-orange-600/20 text-orange-400">活板门</span>
                    </div>
                    <div class="space-y-2 mb-4">
                        <div class="flex justify-between">
                            <span class="text-gray-400">坐标</span>
                            <span class="text-white">${preset.x}, ${preset.y}, ${preset.z}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-400">ID</span>
                            <span class="text-gray-500 text-sm">${preset.id.substring(0, 8)}...</span>
                        </div>
                        ${preset.description ? `
                        <div class="flex justify-between">
                            <span class="text-gray-400">描述</span>
                            <span class="text-gray-300 text-sm">${preset.description}</span>
                        </div>
                        ` : ''}
                    </div>
                    <div class="flex space-x-2">
                        <button onclick="robotController.editPreset('trapdoor', '${preset.id}')" class="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-3 rounded text-sm font-medium transition-colors">
                            编辑
                        </button>
                        <button onclick="robotController.deletePreset('trapdoor', '${preset.id}')" class="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-3 rounded text-sm font-medium transition-colors">
                            删除
                        </button>
                    </div>
                </div>
            `).join('');
        }
    }

    updateConfigUI() {
        if (!this.config) return;

        // 更新Minecraft配置
        if (this.config.minecraft) {
            document.getElementById('authType').value = this.config.minecraft.auth || 'offline';
            document.getElementById('reconnectDelay').value = this.config.minecraft.reconnectDelay || 5000;
            document.getElementById('maxReconnectAttempts').value = this.config.minecraft.maxReconnectAttempts || 10;
            
            if (this.config.minecraft.loginCommands) {
                document.getElementById('enableLoginCommands').checked = this.config.minecraft.loginCommands.enabled || false;
                document.getElementById('loginPassword').value = this.config.minecraft.loginCommands.password || '';
                document.getElementById('registerCommand').value = this.config.minecraft.loginCommands.registerCommand || '/register {password} {password}';
                document.getElementById('loginCommand').value = this.config.minecraft.loginCommands.loginCommand || '/login {password}';
                
                document.getElementById('loginCommandsSection').classList.toggle('hidden', !this.config.minecraft.loginCommands.enabled);
            }
        }

        // 更新机器人配置
        if (this.config.robot) {
            if (this.config.robot.movement) {
                document.getElementById('moveTimeout').value = this.config.robot.movement.moveTimeout || 60000;
                document.getElementById('arrivalDistance').value = this.config.robot.movement.arrivalDistance || 2;
            }
            
            if (this.config.robot.tasks) {
                document.getElementById('taskTimeout').value = this.config.robot.tasks.taskTimeout || 300000;
                document.getElementById('retryAttempts').value = this.config.robot.tasks.retryAttempts || 3;
            }
            
            if (this.config.robot.safety) {
                document.getElementById('autoEat').checked = this.config.robot.safety.autoEat || false;
                document.getElementById('avoidHostile').checked = this.config.robot.safety.avoidHostile || false;
            }
        }
    }

    updateUsersTable() {
        const tbody = document.getElementById('usersTableBody');
        
        if (this.users.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="4" class="text-center py-8 text-gray-400">暂无用户</td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = this.users.map(user => `
            <tr class="border-b border-gray-700 hover:bg-gray-800/50">
                <td class="py-3 px-4 text-white">${user.username}</td>
                <td class="py-3 px-4">
                    <span class="px-2 py-1 text-xs rounded-full ${user.role === 'admin' ? 'bg-orange-600/20 text-orange-400' : 'bg-blue-600/20 text-blue-400'}">
                        ${user.role === 'admin' ? '管理员' : '普通用户'}
                    </span>
                </td>
                <td class="py-3 px-4 text-gray-400">${new Date(user.createdAt).toLocaleString()}</td>
                <td class="py-3 px-4">
                    <div class="flex space-x-2">
                        <button onclick="robotController.showPasswordModal('${user.username}')" class="text-sm text-blue-400 hover:text-blue-300">
                            修改密码
                        </button>
                        ${user.username !== this.currentUser.username ? `
                        <button onclick="robotController.deleteUser('${user.username}')" class="text-sm text-red-400 hover:text-red-300">
                            删除
                        </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
        `).join('');
    }

    updateUserInfo() {
        document.getElementById('currentUser').textContent = this.currentUser.username || 'Unknown';
        
        const roleBadge = document.getElementById('userRole');
        if (this.currentUser.role === 'admin') {
            roleBadge.textContent = '管理员';
            roleBadge.className = 'ml-2 px-2 py-1 text-xs rounded bg-orange-600/20 text-orange-400';
        } else {
            roleBadge.textContent = '普通用户';
            roleBadge.className = 'ml-2 px-2 py-1 text-xs rounded bg-blue-600/20 text-blue-400';
        }
    }

    // 机器人控制
    async connectBot() {
        const host = document.getElementById('serverHost').value;
        const port = parseInt(document.getElementById('serverPort').value);
        const username = document.getElementById('botUsername').value;
        const version = document.getElementById('minecraftVersion').value;
        
        if (!host || !port || !username) {
            this.addLog('错误', '请填写完整的服务器信息', 'error');
            return;
        }

        try {
            const response = await fetch('/api/bot/connect', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.authToken}`
                },
                body: JSON.stringify({
                    host,
                    port,
                    username,
                    version,
                    auth: 'offline'
                })
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('机器人', '连接命令已发送', 'success');
            } else {
                this.addLog('错误', result.error || '连接失败', 'error');
            }
        } catch (error) {
            console.error('连接机器人失败:', error);
            this.addLog('错误', '网络错误，连接失败', 'error');
        }
    }

    async disconnectBot() {
        try {
            const response = await fetch('/api/bot/disconnect', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('机器人', '已断开连接', 'warning');
            } else {
                this.addLog('错误', result.error || '断开连接失败', 'error');
            }
        } catch (error) {
            console.error('断开机器人失败:', error);
            this.addLog('错误', '网络错误，断开连接失败', 'error');
        }
    }

    async testConnection() {
        const host = document.getElementById('serverHost').value;
        const port = parseInt(document.getElementById('serverPort').value);
        
        if (!host || !port) {
            this.addLog('错误', '请填写服务器地址和端口', 'error');
            return;
        }

        this.addLog('系统', `正在测试连接 ${host}:${port}...`, 'info');
        
        // 这里可以添加实际的连接测试逻辑
        setTimeout(() => {
            this.addLog('系统', '连接测试完成（模拟）', 'success');
        }, 2000);
    }

    // 任务控制
    async startTask() {
        const trapdoorId = document.getElementById('trapdoorSelect').value;
        const standbyId = document.getElementById('standbySelect').value;
        
        if (!trapdoorId || !standbyId) {
            this.addLog('错误', '请选择目标活板门和待机点', 'error');
            return;
        }

        try {
            const response = await fetch('/api/task/start', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.authToken}`
                },
                body: JSON.stringify({ trapdoorId, standbyId })
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('任务', '任务启动成功', 'success');
            } else {
                this.addLog('错误', result.error || '任务启动失败', 'error');
            }
        } catch (error) {
            console.error('启动任务失败:', error);
            this.addLog('错误', '网络错误，任务启动失败', 'error');
        }
    }

    async stopTask() {
        try {
            const response = await fetch('/api/task/stop', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('任务', '任务已停止', 'warning');
            } else {
                this.addLog('错误', result.error || '停止任务失败', 'error');
            }
        } catch (error) {
            console.error('停止任务失败:', error);
            this.addLog('错误', '网络错误，停止任务失败', 'error');
        }
    }

    // 预设点管理
    showPresetModal(type, presetId = null) {
        const modal = document.getElementById('presetModal');
        const title = document.getElementById('presetModalTitle');
        const form = document.getElementById('presetForm');
        
        this.currentPresetType = type;
        this.currentPresetId = presetId;
        
        if (presetId) {
            // 编辑模式
            const preset = type === 'standby' ? 
                this.presets.standbyPoints.find(p => p.id === presetId) :
                this.presets.trapdoorPoints.find(p => p.id === presetId);
            
            if (preset) {
                title.textContent = `编辑${type === 'standby' ? '待机点' : '活板门'}`;
                document.getElementById('presetName').value = preset.name;
                document.getElementById('presetX').value = preset.x;
                document.getElementById('presetY').value = preset.y;
                document.getElementById('presetZ').value = preset.z;
                document.getElementById('presetDescription').value = preset.description || '';
            }
        } else {
            // 添加模式
            title.textContent = `添加${type === 'standby' ? '待机点' : '活板门'}`;
            form.reset();
        }
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    hidePresetModal() {
        const modal = document.getElementById('presetModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        
        this.currentPresetType = null;
        this.currentPresetId = null;
    }

    editPreset(type, id) {
        this.showPresetModal(type, id);
    }

    async deletePreset(type, id) {
        if (!confirm(`确定要删除这个${type === 'standby' ? '待机点' : '活板门'}吗？`)) {
            return;
        }

        try {
            const response = await fetch(`/api/presets/${type}/${id}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('预设点', '预设点删除成功', 'success');
                await this.loadPresets();
            } else {
                this.addLog('错误', result.error || '删除预设点失败', 'error');
            }
        } catch (error) {
            console.error('删除预设点失败:', error);
            this.addLog('错误', '网络错误，删除预设点失败', 'error');
        }
    }

    async savePreset() {
        const name = document.getElementById('presetName').value.trim();
        const x = parseInt(document.getElementById('presetX').value);
        const y = parseInt(document.getElementById('presetY').value);
        const z = parseInt(document.getElementById('presetZ').value);
        const description = document.getElementById('presetDescription').value.trim();

        if (!name || isNaN(x) || isNaN(y) || isNaN(z)) {
            this.addLog('错误', '请填写所有必填字段', 'error');
            return;
        }

        const presetData = { name, x, y, z, description };

        try {
            let response;
            
            if (this.currentPresetId) {
                // 更新预设点
                response = await fetch(`/api/presets/${this.currentPresetType}/${this.currentPresetId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${this.authToken}`
                    },
                    body: JSON.stringify(presetData)
                });
            } else {
                // 添加预设点
                response = await fetch('/api/presets', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${this.authToken}`
                    },
                    body: JSON.stringify({
                        type: this.currentPresetType,
                        ...presetData
                    })
                });
            }

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('预设点', `预设点 "${name}" ${this.currentPresetId ? '更新' : '添加'}成功`, 'success');
                this.hidePresetModal();
                await this.loadPresets();
            } else {
                this.addLog('错误', result.error || `${this.currentPresetId ? '更新' : '添加'}预设点失败`, 'error');
            }
        } catch (error) {
            console.error('保存预设点失败:', error);
            this.addLog('错误', '网络错误，保存预设点失败', 'error');
        }
    }

    // 配置管理
    async saveConfig() {
        const config = {
            minecraft: {
                auth: document.getElementById('authType').value,
                reconnectDelay: parseInt(document.getElementById('reconnectDelay').value),
                maxReconnectAttempts: parseInt(document.getElementById('maxReconnectAttempts').value),
                loginCommands: {
                    enabled: document.getElementById('enableLoginCommands').checked,
                    password: document.getElementById('loginPassword').value,
                    registerCommand: document.getElementById('registerCommand').value,
                    loginCommand: document.getElementById('loginCommand').value
                }
            },
            robot: {
                movement: {
                    moveTimeout: parseInt(document.getElementById('moveTimeout').value),
                    arrivalDistance: parseInt(document.getElementById('arrivalDistance').value)
                },
                tasks: {
                    taskTimeout: parseInt(document.getElementById('taskTimeout').value),
                    retryAttempts: parseInt(document.getElementById('retryAttempts').value)
                },
                safety: {
                    autoEat: document.getElementById('autoEat').checked,
                    avoidHostile: document.getElementById('avoidHostile').checked
                }
            }
        };

        try {
            const response = await fetch('/api/config', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.authToken}`
                },
                body: JSON.stringify(config)
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('配置', '配置已保存', 'success');
                this.config = { ...this.config, ...config };
            } else {
                this.addLog('错误', result.error || '保存配置失败', 'error');
            }
        } catch (error) {
            console.error('保存配置失败:', error);
            this.addLog('错误', '网络错误，保存配置失败', 'error');
        }
    }

    async resetConfig() {
        if (!confirm('确定要重置为默认配置吗？这将覆盖当前的所有配置。')) {
            return;
        }

        try {
            // 这里可以添加重置为默认配置的逻辑
            this.addLog('配置', '配置重置功能开发中...', 'info');
        } catch (error) {
            console.error('重置配置失败:', error);
            this.addLog('错误', '重置配置失败', 'error');
        }
    }

    async backupConfig() {
        try {
            // 创建配置备份
            const backupData = {
                config: this.config,
                presets: this.presets,
                timestamp: new Date().toISOString(),
                version: '1.0'
            };

            const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `robot-config-backup-${Date.now()}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            
            URL.revokeObjectURL(url);
            this.addLog('配置', '配置备份已下载', 'success');
        } catch (error) {
            console.error('备份配置失败:', error);
            this.addLog('错误', '备份配置失败', 'error');
        }
    }

    // 用户管理
    showUserModal() {
        const modal = document.getElementById('userModal');
        document.getElementById('userForm').reset();
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    hideUserModal() {
        const modal = document.getElementById('userModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }

    async addUser() {
        const username = document.getElementById('newUsername').value.trim();
        const password = document.getElementById('newPassword').value;
        const role = document.getElementById('newUserRole').value;

        if (!username || !password) {
            this.addLog('错误', '请填写用户名和密码', 'error');
            return;
        }

        try {
            const response = await fetch('/api/users', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.authToken}`
                },
                body: JSON.stringify({ username, password, role })
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('用户', `用户 "${username}" 添加成功`, 'success');
                this.hideUserModal();
                await this.loadUsers();
            } else {
                this.addLog('错误', result.error || '添加用户失败', 'error');
            }
        } catch (error) {
            console.error('添加用户失败:', error);
            this.addLog('错误', '网络错误，添加用户失败', 'error');
        }
    }

    async deleteUser(username) {
        if (!confirm(`确定要删除用户 "${username}" 吗？`)) {
            return;
        }

        try {
            const response = await fetch(`/api/users/${username}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('用户', `用户 "${username}" 删除成功`, 'success');
                await this.loadUsers();
            } else {
                this.addLog('错误', result.error || '删除用户失败', 'error');
            }
        } catch (error) {
            console.error('删除用户失败:', error);
            this.addLog('错误', '网络错误，删除用户失败', 'error');
        }
    }

    showPasswordModal(username) {
        const modal = document.getElementById('passwordModal');
        document.getElementById('passwordUsername').value = username;
        document.getElementById('passwordForm').reset();
        
        // 如果是管理员修改其他用户的密码，隐藏旧密码字段
        const oldPasswordSection = document.getElementById('oldPasswordSection');
        if (this.currentUser.role === 'admin' && username !== this.currentUser.username) {
            oldPasswordSection.style.display = 'none';
        } else {
            oldPasswordSection.style.display = 'block';
        }
        
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }

    hidePasswordModal() {
        const modal = document.getElementById('passwordModal');
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }

    async changePassword() {
        const username = document.getElementById('passwordUsername').value;
        const oldPassword = document.getElementById('oldPassword').value;
        const newPassword = document.getElementById('newPasswordInput').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword !== confirmPassword) {
            this.addLog('错误', '新密码和确认密码不匹配', 'error');
            return;
        }

        if (!newPassword) {
            this.addLog('错误', '新密码不能为空', 'error');
            return;
        }

        try {
            const response = await fetch(`/api/users/${username}/password`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.authToken}`
                },
                body: JSON.stringify({
                    oldPassword: this.currentUser.role === 'admin' && username !== this.currentUser.username ? undefined : oldPassword,
                    newPassword
                })
            });

            const result = await response.json();
            
            if (response.ok) {
                this.addLog('用户', '密码修改成功', 'success');
                this.hidePasswordModal();
            } else {
                this.addLog('错误', result.error || '密码修改失败', 'error');
            }
        } catch (error) {
            console.error('修改密码失败:', error);
            this.addLog('错误', '网络错误，密码修改失败', 'error');
        }
    }

    // 日志管理
    addLog(source, message, type = 'info') {
        const timestamp = new Date().toLocaleTimeString();
        const logEntry = {
            source,
            message,
            type,
            timestamp
        };

        this.logs.push(logEntry);
        
        // 限制日志数量
        if (this.logs.length > 200) {
            this.logs.shift();
        }

        this.renderLog(logEntry);
    }

    renderLog(logEntry) {
        const container = document.getElementById('logContainer');
        const colors = {
            info: 'text-blue-400',
            success: 'text-green-400',
            warning: 'text-yellow-400',
            error: 'text-red-400'
        };

        const logElement = document.createElement('div');
        logElement.className = 'log-entry';
        logElement.innerHTML = `
            <span class="text-gray-400">[${logEntry.source}]</span>
            <span class="text-white ml-2">${logEntry.message}</span>
            <span class="${colors[logEntry.type]} text-xs ml-2">[${logEntry.timestamp}]</span>
        `;

        container.appendChild(logElement);
        
        // 自动滚动到底部
        container.scrollTop = container.scrollHeight;
    }

    clearLogs() {
        this.logs = [];
        document.getElementById('logContainer').innerHTML = '';
        this.addLog('系统', '日志已清除', 'info');
    }

    exportLogs() {
        const logData = {
            logs: this.logs,
            exportTime: new Date().toISOString(),
            systemInfo: {
                userAgent: navigator.userAgent,
                url: window.location.href
            }
        };

        const blob = new Blob([JSON.stringify(logData, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        
        const a = document.createElement('a');
        a.href = url;
        a.download = `robot-logs-${Date.now()}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        URL.revokeObjectURL(url);
        this.addLog('系统', '日志已导出', 'success');
    }

    // 页面切换
    switchPage(page) {
        // 更新导航状态
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-page="${page}"]`).classList.add('active');

        // 显示对应页面
        document.querySelectorAll('.page-content').forEach(content => {
            content.classList.add('hidden');
        });
        document.getElementById(`${page}Page`).classList.remove('hidden');

        // 加载页面特定数据
        if (page === 'users' && this.currentUser.role === 'admin') {
            this.loadUsers();
        } else if (page === 'config') {
            this.updateConfigUI();
        }
    }

    // 定期更新
    startPeriodicUpdates() {
        // 每30秒更新一次状态
        setInterval(() => {
            this.updateSystemStatus();
        }, 30000);
    }

    async updateSystemStatus() {
        try {
            const response = await fetch('/api/system-status', {
                headers: {
                    'Authorization': `Bearer ${this.authToken}`
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                this.updateBotStatus(data.bot);
            }
        } catch (error) {
            console.error('更新系统状态失败:', error);
        }
    }

    logout() {
        localStorage.clear();
        window.location.href = '/login.html';
    }
}

// 初始化控制器
let robotController;

document.addEventListener('DOMContentLoaded', () => {
    robotController = new EnhancedRobotController();
    
    // 页面加载动画
    anime({
        targets: '.glass-panel',
        translateY: [20, 0],
        opacity: [0, 1],
        duration: 600,
        delay: anime.stagger(100),
        easing: 'easeOutQuad'
    });
});