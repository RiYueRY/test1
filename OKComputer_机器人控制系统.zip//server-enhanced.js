const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const ConfigManager = require('./config-manager');
const EnhancedMinecraftBot = require('./enhanced-bot');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// 全局变量
let configManager;
let minecraftBot;
let sessions = new Map();

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// JWT验证中间件
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: '访问令牌缺失' });
  }

  const config = configManager.getConfig();
  jwt.verify(token, config.server.jwtSecret, (err, user) => {
    if (err) {
      return res.status(403).json({ error: '无效的访问令牌' });
    }
    req.user = user;
    next();
  });
};

// 管理员权限验证
const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: '需要管理员权限' });
  }
  next();
};

// 初始化系统
async function initializeSystem() {
  try {
    console.log('🚀 启动机器人控制系统...');
    
    // 初始化配置管理器
    configManager = new ConfigManager('config.json');
    await configManager.init();
    configManager.setSocketIO(io);
    
    // 验证配置
    const configErrors = configManager.validateConfig();
    if (configErrors.length > 0) {
      console.warn('⚠️  配置验证警告:', configErrors);
    }
    
    // 初始化机器人（如果启用）
    const config = configManager.getConfig();
    if (config.minecraft.enableBot) {
      await initializeBot();
    }
    
    console.log('✅ 系统初始化完成');
    
  } catch (error) {
    console.error('❌ 系统初始化失败:', error);
    process.exit(1);
  }
}

// 初始化机器人
async function initializeBot() {
  try {
    console.log('🤖 初始化Minecraft机器人...');
    
    minecraftBot = new EnhancedMinecraftBot(configManager);
    await minecraftBot.createBot();
    
    console.log('✅ 机器人初始化完成');
    
  } catch (error) {
    console.error('机器人初始化失败:', error);
    console.log('⚠️  将继续使用模拟模式运行');
  }
}

// API 路由

// 登录路由
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const user = await configManager.validateUser(username, password);
    if (!user) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    const config = configManager.getConfig();
    const token = jwt.sign(
      { userId: user.id, username: user.username, role: user.role },
      config.server.jwtSecret,
      { expiresIn: '24h' }
    );

    const sessionId = uuidv4();
    sessions.set(sessionId, {
      userId: user.id,
      username: user.username,
      role: user.role,
      createdAt: new Date()
    });

    res.json({
      token,
      sessionId,
      user: {
        id: user.id,
        username: user.username,
        role: user.role
      }
    });
  } catch (error) {
    console.error('登录错误:', error);
    res.status(500).json({ error: '服务器内部错误' });
  }
});

// 验证令牌路由
app.get('/api/verify', authenticateToken, (req, res) => {
  res.json({ valid: true, user: req.user });
});

// 获取系统状态
app.get('/api/system-status', authenticateToken, (req, res) => {
  const config = configManager.getConfig();
  const botStatus = minecraftBot ? minecraftBot.getStatus() : getMockBotStatus();
  
  res.json({
    bot: botStatus,
    config: {
      minecraft: config.minecraft,
      robot: config.robot,
      presets: config.presets
    },
    system: {
      uptime: process.uptime(),
      memory: process.memoryUsage(),
      version: require('./package.json').version
    }
  });
});

// 获取机器人状态
app.get('/api/bot-status', authenticateToken, (req, res) => {
  const botStatus = minecraftBot ? minecraftBot.getStatus() : getMockBotStatus();
  res.json(botStatus);
});

// 控制机器人连接
app.post('/api/bot/connect', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { host, port, username, version, auth, password } = req.body;
    
    // 更新配置
    const newConfig = { host, port, username, version, auth };
    if (password) newConfig.password = password;
    newConfig.enableBot = true;
    
    await configManager.updateMinecraftConfig(newConfig);
    
    // 初始化机器人
    await initializeBot();
    
    res.json({ success: true, message: '机器人连接命令已发送' });
  } catch (error) {
    console.error('连接机器人失败:', error);
    res.status(500).json({ error: '连接机器人失败' });
  }
});

// 断开机器人连接
app.post('/api/bot/disconnect', authenticateToken, requireAdmin, (req, res) => {
  try {
    if (minecraftBot) {
      minecraftBot.disconnect();
      minecraftBot = null;
    }
    
    res.json({ success: true, message: '机器人已断开连接' });
  } catch (error) {
    console.error('断开机器人失败:', error);
    res.status(500).json({ error: '断开机器人失败' });
  }
});

// 预设点管理
app.get('/api/presets', authenticateToken, (req, res) => {
  const presets = configManager.getPresets();
  res.json(presets);
});

app.post('/api/presets', authenticateToken, async (req, res) => {
  try {
    const { type, name, x, y, z, description } = req.body;
    
    const preset = await configManager.addPreset(type, {
      name, x, y, z, description
    });
    
    res.json(preset);
  } catch (error) {
    console.error('添加预设点失败:', error);
    res.status(500).json({ error: error.message });
  }
});

app.put('/api/presets/:type/:id', authenticateToken, async (req, res) => {
  try {
    const { type, id } = req.params;
    const { name, x, y, z, description } = req.body;
    
    const preset = await configManager.updatePreset(type, id, {
      name, x, y, z, description
    });
    
    res.json(preset);
  } catch (error) {
    console.error('更新预设点失败:', error);
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/presets/:type/:id', authenticateToken, async (req, res) => {
  try {
    const { type, id } = req.params;
    await configManager.deletePreset(type, id);
    res.json({ success: true });
  } catch (error) {
    console.error('删除预设点失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 任务控制
app.post('/api/task/start', authenticateToken, async (req, res) => {
  try {
    const { trapdoorId, standbyId } = req.body;
    
    if (!minecraftBot || !minecraftBot.isConnected) {
      return res.status(400).json({ error: '机器人未连接' });
    }
    
    if (minecraftBot.currentTask) {
      return res.status(400).json({ error: '已有任务正在执行' });
    }
    
    await minecraftBot.executeTask(trapdoorId, standbyId);
    
    res.json({ success: true, message: '任务已开始' });
  } catch (error) {
    console.error('启动任务失败:', error);
    res.status(500).json({ error: error.message });
  }
});

app.post('/api/task/stop', authenticateToken, (req, res) => {
  try {
    if (minecraftBot) {
      minecraftBot.stopCurrentTask();
    }
    
    res.json({ success: true, message: '任务已停止' });
  } catch (error) {
    console.error('停止任务失败:', error);
    res.status(500).json({ error: '停止任务失败' });
  }
});

// 配置管理
app.get('/api/config', authenticateToken, requireAdmin, (req, res) => {
  const config = configManager.getConfig();
  // 移除敏感信息
  const safeConfig = {
    server: {
      port: config.server.port,
      sessionTimeout: config.server.sessionTimeout
    },
    minecraft: {
      host: config.minecraft.host,
      port: config.minecraft.port,
      username: config.minecraft.username,
      version: config.minecraft.version,
      auth: config.minecraft.auth,
      enableBot: config.minecraft.enableBot,
      reconnectDelay: config.minecraft.reconnectDelay,
      maxReconnectAttempts: config.minecraft.maxReconnectAttempts,
      loginCommands: config.minecraft.loginCommands
    },
    robot: config.robot,
    presets: config.presets
  };
  
  res.json(safeConfig);
});

app.put('/api/config', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { minecraft, robot } = req.body;
    
    if (minecraft) {
      await configManager.updateMinecraftConfig(minecraft);
    }
    
    if (robot) {
      await configManager.updateRobotConfig(robot);
    }
    
    res.json({ success: true, message: '配置已更新' });
  } catch (error) {
    console.error('更新配置失败:', error);
    res.status(500).json({ error: '更新配置失败' });
  }
});

// 用户管理
app.get('/api/users', authenticateToken, requireAdmin, (req, res) => {
  const users = configManager.getUsers().map(user => {
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  });
  res.json(users);
});

app.post('/api/users', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { username, password, role } = req.body;
    const user = await configManager.addUser({ username, password, role });
    res.json(user);
  } catch (error) {
    console.error('添加用户失败:', error);
    res.status(500).json({ error: error.message });
  }
});

app.delete('/api/users/:username', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { username } = req.params;
    
    // 防止删除最后一个管理员
    const adminCount = configManager.getUsers().filter(u => u.role === 'admin').length;
    const user = configManager.getUsers().find(u => u.username === username);
    
    if (user && user.role === 'admin' && adminCount <= 1) {
      return res.status(400).json({ error: '不能删除最后一个管理员' });
    }
    
    await configManager.deleteUser(username);
    res.json({ success: true });
  } catch (error) {
    console.error('删除用户失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// 修改密码
app.put('/api/users/:username/password', authenticateToken, async (req, res) => {
  try {
    const { username } = req.params;
    const { oldPassword, newPassword } = req.body;
    
    // 用户只能修改自己的密码，除非是管理员
    if (req.user.username !== username && req.user.role !== 'admin') {
      return res.status(403).json({ error: '只能修改自己的密码' });
    }
    
    // 如果不是管理员，需要验证旧密码
    if (req.user.role !== 'admin') {
      const user = await configManager.validateUser(username, oldPassword);
      if (!user) {
        return res.status(400).json({ error: '旧密码错误' });
      }
    }
    
    await configManager.updateUserPassword(username, newPassword);
    res.json({ success: true, message: '密码已更新' });
  } catch (error) {
    console.error('修改密码失败:', error);
    res.status(500).json({ error: error.message });
  }
});

// Socket.io 事件处理
io.on('connection', (socket) => {
  console.log('客户端已连接:', socket.id);
  
  // 发送初始状态
  const botStatus = minecraftBot ? minecraftBot.getStatus() : getMockBotStatus();
  const presets = configManager.getPresets();
  const config = configManager.getConfig();
  
  socket.emit('botStatusUpdated', botStatus);
  socket.emit('presetsUpdated', presets);
  socket.emit('configUpdated', {
    minecraft: config.minecraft,
    robot: config.robot,
    presets: config.presets
  });
  
  // 断开连接处理
  socket.on('disconnect', () => {
    console.log('客户端已断开:', socket.id);
  });
});

// 模拟机器人状态（当机器人未连接时）
function getMockBotStatus() {
  const config = configManager.getConfig();
  return {
    connected: false,
    position: { x: 0, y: 64, z: 0 },
    health: 20,
    food: 20,
    currentTask: null,
    players: []
  };
}

// 定期更新状态
setInterval(() => {
  if (minecraftBot && minecraftBot.isConnected) {
    const status = minecraftBot.getStatus();
    io.emit('botStatusUpdated', status);
  }
}, 3000);

// 启动服务器
async function startServer() {
  try {
    await initializeSystem();
    
    const config = configManager.getConfig();
    const port = config.server.port;
    
    server.listen(port, () => {
      console.log(`🚀 服务器运行在端口 ${port}`);
      console.log(`📱 访问地址: http://localhost:${port}`);
      console.log(`👤 默认账号: admin`);
      console.log(`🔑 默认密码: password`);
      console.log('');
      console.log('📋 可用命令:');
      console.log('  - 查看日志: tail -f logs/robot.log');
      console.log('  - 停止服务器: Ctrl+C');
      console.log('');
      console.log('🔧 配置文件:');
      console.log('  - config.json: 主要配置文件');
      console.log('  - .env: 环境变量配置');
      console.log('');
      console.log('📖 详细说明请查看 README.md');
    });
    
  } catch (error) {
    console.error('启动服务器失败:', error);
    process.exit(1);
  }
}

// 优雅关闭
process.on('SIGINT', async () => {
  console.log('\n🛑 收到关闭信号，正在优雅关闭...');
  
  try {
    if (minecraftBot) {
      minecraftBot.disconnect();
    }
    
    server.close(() => {
      console.log('✅ 服务器已关闭');
      process.exit(0);
    });
    
  } catch (error) {
    console.error('关闭过程出错:', error);
    process.exit(1);
  }
});

// 错误处理
process.on('unhandledRejection', (reason, promise) => {
  console.error('未处理的Promise拒绝:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('未捕获的异常:', error);
  process.exit(1);
});

// 启动应用
startServer();