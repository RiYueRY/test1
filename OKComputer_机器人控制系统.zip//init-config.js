#!/usr/bin/env node

const fs = require('fs').promises;
const path = require('path');
const readline = require('readline');
const bcrypt = require('bcryptjs');

class ConfigInitializer {
    constructor() {
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        this.config = {};
    }

    async init() {
        console.log('🚀 Mineflayer 机器人控制系统 - 初始化配置\n');
        console.log('='.repeat(50));
        
        try {
            await this.askBasicConfig();
            await this.askMinecraftConfig();
            await this.askRobotConfig();
            await this.askUserConfig();
            
            await this.saveConfig();
            await this.createDirectories();
            
            console.log('\n✅ 初始化完成！');
            console.log('📋 配置文件已保存到 config.json');
            console.log('📝 您可以随时修改 config.json 来调整配置');
            console.log('\n下一步：');
            console.log('  1. 运行 npm install 安装依赖');
            console.log('  2. 运行 npm start 启动系统');
            console.log('  3. 访问 http://localhost:3000 使用系统');
            
        } catch (error) {
            console.error('❌ 初始化失败:', error);
        } finally {
            this.rl.close();
        }
    }

    async askBasicConfig() {
        console.log('\n📋 基本配置');
        console.log('-'.repeat(30));
        
        this.config.server = {
            port: await this.askQuestion('服务器端口 (默认: 3000): ', '3000'),
            jwtSecret: this.generateRandomSecret(),
            sessionTimeout: 86400000
        };
    }

    async askMinecraftConfig() {
        console.log('\n🎮 Minecraft 配置');
        console.log('-'.repeat(30));
        
        const enableBot = await this.askQuestion('是否启用机器人? (y/n, 默认: n): ', 'n');
        
        this.config.minecraft = {
            host: await this.askQuestion('Minecraft 服务器地址 (默认: localhost): ', 'localhost'),
            port: parseInt(await this.askQuestion('Minecraft 服务器端口 (默认: 25565): ', '25565')),
            username: await this.askQuestion('机器人用户名 (默认: WebRobot): ', 'WebRobot'),
            version: await this.askQuestion('Minecraft 版本 (默认: 1.20.1): ', '1.20.1'),
            auth: 'offline',
            enableBot: enableBot.toLowerCase() === 'y',
            reconnectDelay: 5000,
            maxReconnectAttempts: 10,
            loginCommands: {
                enabled: false,
                registerCommand: '/register {password} {password}',
                loginCommand: '/login {password}',
                password: 'robot123'
            }
        };

        if (this.config.minecraft.enableBot) {
            const enableLoginCommands = await this.askQuestion('是否启用登录插件命令? (y/n, 默认: n): ', 'n');
            if (enableLoginCommands.toLowerCase() === 'y') {
                this.config.minecraft.loginCommands.enabled = true;
                this.config.minecraft.loginCommands.password = await this.askQuestion('登录密码: ', 'robot123');
            }
        }
    }

    async askRobotConfig() {
        console.log('\n🤖 机器人行为配置');
        console.log('-'.repeat(30));
        
        this.config.robot = {
            movement: {
                moveTimeout: parseInt(await this.askQuestion('移动超时时间 (毫秒, 默认: 60000): ', '60000')),
                arrivalDistance: parseInt(await this.askQuestion('到达距离 (方块, 默认: 2): ', '2')),
                pathfindingTimeout: 30000
            },
            tasks: {
                taskTimeout: parseInt(await this.askQuestion('任务超时时间 (毫秒, 默认: 300000): ', '300000')),
                retryAttempts: parseInt(await this.askQuestion('重试次数 (默认: 3): ', '3')),
                retryDelay: 2000
            },
            safety: {
                minHealth: 6,
                autoEat: (await this.askQuestion('是否启用自动进食? (y/n, 默认: y): ', 'y')).toLowerCase() === 'y',
                avoidHostile: (await this.askQuestion('是否避开敌对生物? (y/n, 默认: y): ', 'y')).toLowerCase() === 'y'
            }
        };
    }

    async askUserConfig() {
        console.log('\n👤 用户配置');
        console.log('-'.repeat(30));
        
        const username = await this.askQuestion('管理员用户名 (默认: admin): ', 'admin');
        const password = await this.askQuestion('管理员密码 (默认: password): ', 'password');
        
        const hashedPassword = await bcrypt.hash(password, 10);
        
        this.config.users = [
            {
                id: '1',
                username: username,
                password: hashedPassword,
                role: 'admin',
                createdAt: new Date().toISOString()
            }
        ];
    }

    async askQuestion(question, defaultValue = '') {
        return new Promise((resolve) => {
            this.rl.question(question, (answer) => {
                resolve(answer.trim() || defaultValue);
            });
        });
    }

    generateRandomSecret() {
        return 'jwt_secret_' + Math.random().toString(36).substring(2, 15) + 
               Math.random().toString(36).substring(2, 15);
    }

    async saveConfig() {
        this.config.presets = {
            standbyPoints: [
                {
                    id: 'standby-base',
                    name: '基地待机点',
                    x: 100,
                    y: 64,
                    z: 200,
                    description: '主要基地待命点'
                }
            ],
            trapdoorPoints: [
                {
                    id: 'trapdoor-1',
                    name: '主活板门',
                    x: 150,
                    y: 64,
                    z: 250,
                    description: '基地主入口活板门'
                }
            ]
        };

        this.config.logging = {
            level: 'info',
            file: 'logs/robot.log',
            maxSize: '10m',
            maxFiles: 5
        };

        await fs.writeFile('config.json', JSON.stringify(this.config, null, 2));
    }

    async createDirectories() {
        try {
            await fs.mkdir('logs', { recursive: true });
            await fs.mkdir('backups', { recursive: true });
            console.log('✅ 必要目录已创建');
        } catch (error) {
            console.log('⚠️  目录创建失败（可能已存在）');
        }
    }
}

// 运行初始化器
if (require.main === module) {
    const initializer = new ConfigInitializer();
    initializer.init();
}

module.exports = ConfigInitializer;