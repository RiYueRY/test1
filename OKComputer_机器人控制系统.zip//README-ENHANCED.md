# Mineflayer 机器人控制系统 - 增强版

一个功能强大的基于Web的Mineflayer机器人控制面板，具有断线重连、离线服务器认证、高级配置管理等增强功能。

## 🌟 增强功能特性

### 🔐 安全与认证
- ✅ 强制登录验证，防止未授权访问
- ✅ JWT令牌管理和会话超时保护
- ✅ 用户权限管理（管理员/普通用户）
- ✅ 密码加密存储
- ✅ 多用户支持

### 🤖 增强机器人功能
- ✅ **断线重连机制** - 自动检测连接状态并重连
- ✅ **离线服务器支持** - 自动处理 /login /register 命令
- ✅ **智能路径规划** - 自动寻找最佳路径
- ✅ **任务队列系统** - 支持多个任务排队执行
- ✅ **错误恢复** - 任务失败自动重试和恢复
- ✅ **安全保护** - 自动避开敌对生物，低血量保护

### 📍 高级预设点管理
- ✅ 多个待机点和活板门预设
- ✅ 预设点坐标精确管理
- ✅ 预设点描述和分类
- ✅ 实时预设点状态显示

### ⚙️ 系统配置管理
- ✅ **Web界面配置** - 无需修改配置文件
- ✅ **实时配置更新** - 修改后立即生效
- ✅ **配置备份恢复** - 支持配置导入导出
- ✅ **详细配置选项** - 机器人行为、安全设置等

### 📊 增强监控
- ✅ 实时状态监控（位置、生命值、饥饿值）
- ✅ 任务进度跟踪和步骤显示
- ✅ 重连次数统计
- ✅ 详细操作日志
- ✅ 日志导出功能

## 🏗️ 技术架构

### 后端技术栈
- **Node.js + Express.js** - 高性能Web服务器
- **Socket.io** - 实时双向通信
- **Mineflayer + Pathfinder** - Minecraft机器人控制
- **JWT** - 安全身份认证
- **Bcrypt** - 密码加密
- **UUID** - 唯一标识生成

### 前端技术栈
- **HTML5 + CSS3 + JavaScript** - 现代化前端
- **Tailwind CSS** - 响应式设计
- **Socket.io Client** - 实时通信
- **Anime.js** - 流畅动画效果
- **ECharts** - 数据可视化

## 🚀 快速开始

### 1. 克隆项目

```bash
git clone https://github.com/your-username/mineflayer-web-controller-enhanced.git
cd mineflayer-web-controller-enhanced
```

### 2. 安装依赖

```bash
npm install
```

### 3. 初始化配置

```bash
npm run init
```

按照提示完成配置：
- 设置服务器端口
- 配置Minecraft服务器信息
- 设置机器人用户名和版本
- 创建管理员账户

### 4. 启动系统

```bash
npm start
```

系统启动后，访问：`http://localhost:3000`

### 5. 默认登录信息

- 用户名：您在初始化时设置的用户名（默认：admin）
- 密码：您在初始化时设置的密码（默认：password）

## 📋 使用指南

### 连接机器人

1. **进入控制面板**
2. **填写服务器信息**：
   - 服务器地址（如：localhost）
   - 端口（默认：25565）
   - 机器人用户名
   - Minecraft版本
3. **点击"连接机器人"**
4. **等待连接成功**

### 配置离线服务器认证

1. **进入系统配置页面**
2. **启用登录插件命令**
3. **设置认证命令**：
   - 注册命令（如：/register {password} {password}）
   - 登录命令（如：/login {password}）
   - 登录密码
4. **保存配置**

### 创建预设点

1. **进入预设点管理页面**
2. **添加待机点**：
   - 点击"添加待机点"
   - 输入名称、坐标、描述
   - 保存预设点
3. **添加活板门**：
   - 点击"添加活板门"
   - 输入名称、坐标、描述
   - 保存预设点

### 执行任务

1. **返回控制面板**
2. **选择任务参数**：
   - 目标活板门
   - 返回待机点
3. **点击"开始任务"**
4. **监控任务执行状态**

### 用户管理（管理员）

1. **进入用户管理页面**
2. **添加用户**：
   - 点击"添加用户"
   - 设置用户名、密码、角色
   - 保存用户
3. **修改密码**：
   - 点击用户行的"修改密码"
   - 输入新密码
   - 确认修改

## 🔧 高级配置

### 机器人行为配置

在系统配置页面可以调整：
- **移动设置**：移动超时、到达距离
- **任务设置**：任务超时、重试次数
- **安全设置**：自动进食、避开敌对生物

### 断线重连配置

- **重连延迟**：断开后的重连等待时间
- **最大重连次数**：防止无限重连
- **认证方式**：离线模式或正版认证

### 日志管理

- **实时日志**：查看机器人操作记录
- **日志导出**：保存日志到本地文件
- **日志清理**：清除过期日志

## 🛡️ 安全建议

### 生产环境部署

1. **修改默认配置**：
   ```bash
   npm run init
   ```

2. **使用强密码**：为管理员账户设置复杂密码

3. **配置防火墙**：限制访问IP地址

4. **启用HTTPS**：在生产环境中使用SSL证书

5. **定期备份**：使用配置备份功能保存设置

### 安全特性

- ✅ 密码加密存储
- ✅ JWT令牌认证
- ✅ 会话超时管理
- ✅ 操作权限控制
- ✅ 输入验证和过滤
- ✅ 错误信息脱敏

## 🐛 故障排除

### 常见问题

#### 机器人无法连接

1. **检查服务器状态**
   ```bash
   ping your-server-ip
   ```

2. **验证端口开放**
   ```bash
   telnet your-server-ip 25565
   ```

3. **检查防火墙设置**

4. **确认Minecraft版本匹配**

#### 任务执行失败

1. **检查预设点坐标** - 确保坐标正确可达
2. **验证路径畅通** - 确保没有障碍物
3. **检查机器人状态** - 确保机器人在线且健康
4. **查看实时日志** - 获取详细错误信息

#### 认证失败

1. **验证用户名密码**
2. **检查JWT密钥配置**
3. **清除浏览器缓存**
4. **检查令牌有效期**

### 调试模式

启动开发模式获取详细日志：

```bash
npm run dev
```

## 📁 项目结构

```
mineflayer-web-controller-enhanced/
├── config.json                 # 主配置文件
├── server-enhanced.js          # 增强版服务器
├── enhanced-bot.js            # 增强版机器人类
├── config-manager.js          # 配置管理器
├── init-config.js             # 初始化脚本
├── start.sh                   # 启动脚本
├── package.json               # 项目依赖
├── README-ENHANCED.md         # 增强版说明文档
├── public/                    # 前端文件
│   ├── login.html             # 登录页面
│   ├── dashboard-enhanced.html # 增强版控制面板
│   └── dashboard-enhanced.js   # 增强版前端逻辑
├── logs/                      # 日志目录
└── backups/                   # 备份目录
```

## 🔄 更新日志

### v2.0.0 (增强版)
- ✅ 断线重连机制
- ✅ 离线服务器认证支持
- ✅ Web界面配置管理
- ✅ 多预设点管理
- ✅ 用户权限系统
- ✅ 增强任务系统
- ✅ 详细日志记录
- ✅ 配置备份恢复

### v1.0.0 (基础版)
- ✅ 基础认证系统
- ✅ 机器人状态监控
- ✅ 简单任务控制
- ✅ 预设点管理
- ✅ 实时通信

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个项目！

### 开发环境设置

1. **Fork项目**
2. **克隆到本地**
3. **创建功能分支**
   ```bash
   git checkout -b feature/your-feature
   ```
4. **提交更改**
   ```bash
   git commit -am 'Add some feature'
   ```
5. **推送到分支**
   ```bash
   git push origin feature/your-feature
   ```
6. **创建Pull Request**

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

## 🙏 致谢

- [Mineflayer](https://github.com/PrismarineJS/mineflayer) - 优秀的Minecraft机器人库
- [Socket.io](https://socket.io/) - 实时通信解决方案
- [Tailwind CSS](https://tailwindcss.com/) - 现代化CSS框架
- [Express.js](https://expressjs.com/) - Node.js Web框架

## 📞 联系方式

如有问题或建议，请通过以下方式联系：

- **Issues**: [GitHub Issues](https://github.com/your-username/mineflayer-web-controller-enhanced/issues)
- **Email**: your-email@example.com
- **Discussion**: [GitHub Discussions](https://github.com/your-username/mineflayer-web-controller-enhanced/discussions)

---

**⚠️ 重要提醒**: 请确保在使用此系统时遵守Minecraft服务器的相关规定和法律法规。不要用于恶意目的或违反服务器规则的行为。