const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const MinecraftBot = require('./bot');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-this';

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 模拟用户数据库
const users = [
  {
    id: '1',
    username: 'admin',
    password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' // password
  }
];

// 会话存储
const sessions = new Map();

// 机器人实例
let minecraftBot = null;

// 机器人状态
let botStatus = {
  connected: false,
  position: { x: 0, y: 0, z: 0 },
  health: 20,
  food: 20,
  currentTask: null,
  players: []
};

// 预设点存储
let presetPoints = [
  { id: '1', name: '基地待机点', x: 100, y: 64, z: 200, type: 'standby' },
  { id: '2', name: '活板门1号', x: 150, y: 64, z: 250, type: 'trapdoor' },
  { id: '3', name: '农场待机点', x: 120, y: 64, z: 180, type: 'standby' }
];

// JWT验证中间件
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: '访问令牌缺失' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: '无效的访问令牌' });
    }
    req.user = user;
    next();
  });
};

// 登录路由
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const user = users.find(u => u.username === username);
    if (!user) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: '用户名或密码错误' });
    }

    const token = jwt.sign(
      { userId: user.id, username: user.username },
      JWT_SECRET,
      { expiresIn: '24h' }
    );

    const sessionId = uuidv4();
    sessions.set(sessionId, {
      userId: user.id,
      username: user.username,
      createdAt: new Date()
    });

    res.json({
      token,
      sessionId,
      user: {
        id: user.id,
        username: user.username
      }
    });
  } catch (error) {
    res.status(500).json({ error: '服务器内部错误' });
  }
});

// 验证令牌路由
app.get('/api/verify', authenticateToken, (req, res) => {
  res.json({ valid: true, user: req.user });
});

// 获取机器人状态
app.get('/api/bot-status', authenticateToken, (req, res) => {
  if (minecraftBot && minecraftBot.isConnected) {
    botStatus = minecraftBot.getStatus();
  }
  res.json(botStatus);
});

// 获取预设点
app.get('/api/presets', authenticateToken, (req, res) => {
  res.json(presetPoints);
});

// 添加预设点
app.post('/api/presets', authenticateToken, (req, res) => {
  try {
    const { name, x, y, z, type } = req.body;
    const newPreset = {
      id: uuidv4(),
      name,
      x: parseInt(x),
      y: parseInt(y),
      z: parseInt(z),
      type: type || 'standby'
    };
    
    presetPoints.push(newPreset);
    io.emit('presetsUpdated', presetPoints);
    res.json(newPreset);
  } catch (error) {
    res.status(500).json({ error: '添加预设点失败' });
  }
});

// 更新预设点
app.put('/api/presets/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const { name, x, y, z, type } = req.body;
    
    const presetIndex = presetPoints.findIndex(p => p.id === id);
    if (presetIndex === -1) {
      return res.status(404).json({ error: '预设点不存在' });
    }
    
    presetPoints[presetIndex] = {
      ...presetPoints[presetIndex],
      name,
      x: parseInt(x),
      y: parseInt(y),
      z: parseInt(z),
      type: type || 'standby'
    };
    
    io.emit('presetsUpdated', presetPoints);
    res.json(presetPoints[presetIndex]);
  } catch (error) {
    res.status(500).json({ error: '更新预设点失败' });
  }
});

// 删除预设点
app.delete('/api/presets/:id', authenticateToken, (req, res) => {
  try {
    const { id } = req.params;
    const presetIndex = presetPoints.findIndex(p => p.id === id);
    
    if (presetIndex === -1) {
      return res.status(404).json({ error: '预设点不存在' });
    }
    
    presetPoints.splice(presetIndex, 1);
    io.emit('presetsUpdated', presetPoints);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: '删除预设点失败' });
  }
});

// 开始任务
app.post('/api/task/start', authenticateToken, async (req, res) => {
  try {
    const { trapdoorId, standbyId } = req.body;
    
    const trapdoor = presetPoints.find(p => p.id === trapdoorId && p.type === 'trapdoor');
    const standby = presetPoints.find(p => p.id === standbyId && p.type === 'standby');
    
    if (!trapdoor || !standby) {
      return res.status(400).json({ error: '无效的预设点' });
    }
    
    if (!minecraftBot || !minecraftBot.isConnected) {
      return res.status(400).json({ error: '机器人未连接' });
    }
    
    // 创建任务
    const task = {
      id: uuidv4(),
      status: 'running',
      trapdoor,
      standby,
      startedAt: new Date()
    };
    
    botStatus.currentTask = task;
    io.emit('taskStarted', task);
    
    // 异步执行任务
    executeTaskAsync(trapdoor, standby);
    
    res.json({ success: true, task });
  } catch (error) {
    res.status(500).json({ error: '启动任务失败' });
  }
});

// 停止任务
app.post('/api/task/stop', authenticateToken, (req, res) => {
  try {
    if (minecraftBot) {
      minecraftBot.stopTask();
    }
    
    if (botStatus.currentTask) {
      botStatus.currentTask.status = 'stopped';
      botStatus.currentTask.endedAt = new Date();
      io.emit('taskStopped', botStatus.currentTask);
      botStatus.currentTask = null;
    }
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: '停止任务失败' });
  }
});

// 异步执行任务
async function executeTaskAsync(trapdoor, standby) {
  try {
    await minecraftBot.executeTask(trapdoor, standby);
    
    // 任务完成
    if (botStatus.currentTask) {
      botStatus.currentTask.status = 'completed';
      botStatus.currentTask.endedAt = new Date();
      io.emit('taskStopped', botStatus.currentTask);
      botStatus.currentTask = null;
    }
  } catch (error) {
    console.error('任务执行失败:', error);
    
    // 任务失败
    if (botStatus.currentTask) {
      botStatus.currentTask.status = 'failed';
      botStatus.currentTask.error = error.message;
      botStatus.currentTask.endedAt = new Date();
      io.emit('taskStopped', botStatus.currentTask);
      botStatus.currentTask = null;
    }
  }
}

// Socket.io 连接处理
io.on('connection', (socket) => {
  console.log('客户端已连接:', socket.id);
  
  // 发送初始状态
  socket.emit('botStatusUpdated', botStatus);
  socket.emit('presetsUpdated', presetPoints);
  
  // 断开连接处理
  socket.on('disconnect', () => {
    console.log('客户端已断开:', socket.id);
  });
});

// 定期更新机器人状态
setInterval(() => {
  if (minecraftBot && minecraftBot.isConnected) {
    botStatus = minecraftBot.getStatus();
    io.emit('botStatusUpdated', botStatus);
  }
}, 2000);

// 启动服务器
server.listen(PORT, () => {
  console.log(`服务器运行在端口 ${PORT}`);
  console.log(`访问地址: http://localhost:${PORT}`);
  
  // 初始化机器人（可选）
  if (process.env.ENABLE_BOT === 'true') {
    initializeBot();
  } else {
    // 模拟机器人连接
    setTimeout(() => {
      botStatus.connected = true;
      io.emit('botStatusUpdated', botStatus);
      console.log('模拟机器人已连接');
    }, 3000);
  }
});

// 初始化机器人
function initializeBot() {
  try {
    minecraftBot = new MinecraftBot();
    
    const botOptions = {
      host: process.env.MINECRAFT_HOST || 'localhost',
      port: parseInt(process.env.MINECRAFT_PORT) || 25565,
      username: process.env.MINECRAFT_USERNAME || 'WebRobot',
      version: process.env.MINECRAFT_VERSION || '1.20.1'
    };
    
    console.log('正在连接Minecraft服务器...');
    console.log('配置:', botOptions);
    
    minecraftBot.createBot(botOptions);
    
  } catch (error) {
    console.error('机器人初始化失败:', error);
    
    // 回退到模拟模式
    setTimeout(() => {
      botStatus.connected = true;
      io.emit('botStatusUpdated', botStatus);
      console.log('使用模拟机器人模式');
    }, 3000);
  }
}