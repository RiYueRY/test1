const fs = require('fs').promises;
const path = require('path');

class ConfigManager {
    constructor(configPath = 'config.json') {
        this.configPath = path.resolve(configPath);
        this.config = null;
        this.io = null; // Socket.io 实例
        this.watchers = new Map();
        
        this.init();
    }

    async init() {
        try {
            await this.loadConfig();
            this.setupFileWatcher();
        } catch (error) {
            console.error('配置管理器初始化失败:', error);
            throw error;
        }
    }

    async loadConfig() {
        try {
            const data = await fs.readFile(this.configPath, 'utf8');
            this.config = JSON.parse(data);
            console.log('✅ 配置文件加载成功');
            return this.config;
        } catch (error) {
            if (error.code === 'ENOENT') {
                console.log('配置文件不存在，创建默认配置...');
                await this.createDefaultConfig();
                return this.config;
            } else {
                console.error('加载配置文件失败:', error);
                throw error;
            }
        }
    }

    async createDefaultConfig() {
        this.config = {
            server: {
                port: 3000,
                jwtSecret: this.generateRandomSecret(),
                sessionTimeout: 86400000
            },
            minecraft: {
                host: 'localhost',
                port: 25565,
                username: 'WebRobot_' + Math.floor(Math.random() * 1000),
                version: '1.20.1',
                auth: 'offline',
                password: '',
                enableBot: false,
                reconnectDelay: 5000,
                maxReconnectAttempts: 10,
                loginCommands: {
                    enabled: false,
                    registerCommand: '/register {password} {password}',
                    loginCommand: '/login {password}',
                    password: 'robot123'
                }
            },
            robot: {
                movement: {
                    moveTimeout: 60000,
                    arrivalDistance: 2,
                    pathfindingTimeout: 30000
                },
                tasks: {
                    taskTimeout: 300000,
                    retryAttempts: 3,
                    retryDelay: 2000
                },
                safety: {
                    minHealth: 6,
                    autoEat: true,
                    avoidHostile: true
                }
            },
            presets: {
                standbyPoints: [
                    {
                        id: 'standby-base',
                        name: '基地待机点',
                        x: 100,
                        y: 64,
                        z: 200,
                        description: '主要基地待命点'
                    }
                ],
                trapdoorPoints: [
                    {
                        id: 'trapdoor-1',
                        name: '主活板门',
                        x: 150,
                        y: 64,
                        z: 250,
                        description: '基地主入口活板门'
                    }
                ]
            },
            users: [
                {
                    id: '1',
                    username: 'admin',
                    password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
                    role: 'admin',
                    createdAt: new Date().toISOString()
                }
            ],
            logging: {
                level: 'info',
                file: 'logs/robot.log',
                maxSize: '10m',
                maxFiles: 5
            }
        };

        await this.saveConfig();
        console.log('✅ 默认配置文件已创建');
    }

    generateRandomSecret() {
        return 'jwt_secret_' + Math.random().toString(36).substring(2, 15) + 
               Math.random().toString(36).substring(2, 15);
    }

    async saveConfig() {
        try {
            const data = JSON.stringify(this.config, null, 2);
            await fs.writeFile(this.configPath, data, 'utf8');
            
            // 通知所有监听器
            this.notifyWatchers();
            
            console.log('✅ 配置文件已保存');
        } catch (error) {
            console.error('保存配置文件失败:', error);
            throw error;
        }
    }

    getConfig() {
        return this.config;
    }

    get(path = '') {
        if (!path) return this.config;
        
        const keys = path.split('.');
        let current = this.config;
        
        for (const key of keys) {
            if (current && typeof current === 'object' && key in current) {
                current = current[key];
            } else {
                return undefined;
            }
        }
        
        return current;
    }

    async set(path, value) {
        const keys = path.split('.');
        let current = this.config;
        
        for (let i = 0; i < keys.length - 1; i++) {
            const key = keys[i];
            if (!(key in current) || typeof current[key] !== 'object') {
                current[key] = {};
            }
            current = current[key];
        }
        
        current[keys[keys.length - 1]] = value;
        await this.saveConfig();
    }

    // 预设点管理
    getPresets() {
        return {
            standbyPoints: this.config.presets.standbyPoints || [],
            trapdoorPoints: this.config.presets.trapdoorPoints || []
        };
    }

    async addPreset(type, presetData) {
        const { id, name, x, y, z, description } = presetData;
        
        if (!id || !name || x === undefined || y === undefined || z === undefined) {
            throw new Error('预设点数据不完整');
        }

        const preset = {
            id: id || this.generateId(),
            name,
            x: parseInt(x),
            y: parseInt(y),
            z: parseInt(z),
            description: description || ''
        };

        if (type === 'standby') {
            this.config.presets.standbyPoints.push(preset);
        } else if (type === 'trapdoor') {
            this.config.presets.trapdoorPoints.push(preset);
        } else {
            throw new Error('无效的预设点类型');
        }

        await this.saveConfig();
        return preset;
    }

    async updatePreset(type, id, presetData) {
        const points = type === 'standby' ? 
            this.config.presets.standbyPoints : 
            this.config.presets.trapdoorPoints;
        
        const index = points.findIndex(p => p.id === id);
        if (index === -1) {
            throw new Error('预设点不存在');
        }

        points[index] = {
            ...points[index],
            ...presetData,
            x: presetData.x !== undefined ? parseInt(presetData.x) : points[index].x,
            y: presetData.y !== undefined ? parseInt(presetData.y) : points[index].y,
            z: presetData.z !== undefined ? parseInt(presetData.z) : points[index].z
        };

        await this.saveConfig();
        return points[index];
    }

    async deletePreset(type, id) {
        const points = type === 'standby' ? 
            this.config.presets.standbyPoints : 
            this.config.presets.trapdoorPoints;
        
        const index = points.findIndex(p => p.id === id);
        if (index === -1) {
            throw new Error('预设点不存在');
        }

        points.splice(index, 1);
        await this.saveConfig();
    }

    // Minecraft 配置管理
    getMinecraftConfig() {
        return this.config.minecraft;
    }

    async updateMinecraftConfig(newConfig) {
        this.config.minecraft = {
            ...this.config.minecraft,
            ...newConfig
        };
        await this.saveConfig();
    }

    // 机器人配置管理
    getRobotConfig() {
        return this.config.robot;
    }

    async updateRobotConfig(newConfig) {
        this.config.robot = {
            ...this.config.robot,
            ...newConfig
        };
        await this.saveConfig();
    }

    // 用户管理
    getUsers() {
        return this.config.users;
    }

    async addUser(userData) {
        const bcrypt = require('bcryptjs');
        const { username, password, role = 'user' } = userData;
        
        if (!username || !password) {
            throw new Error('用户名和密码不能为空');
        }

        // 检查用户名是否已存在
        if (this.config.users.find(u => u.username === username)) {
            throw new Error('用户名已存在');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        
        const user = {
            id: this.generateId(),
            username,
            password: hashedPassword,
            role,
            createdAt: new Date().toISOString()
        };

        this.config.users.push(user);
        await this.saveConfig();
        
        // 返回用户数据（不包含密码）
        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
    }

    async updateUserPassword(username, newPassword) {
        const bcrypt = require('bcryptjs');
        const user = this.config.users.find(u => u.username === username);
        
        if (!user) {
            throw new Error('用户不存在');
        }

        user.password = await bcrypt.hash(newPassword, 10);
        await this.saveConfig();
    }

    async deleteUser(username) {
        const index = this.config.users.findIndex(u => u.username === username);
        if (index === -1) {
            throw new Error('用户不存在');
        }

        this.config.users.splice(index, 1);
        await this.saveConfig();
    }

    // 验证用户密码
    async validateUser(username, password) {
        const bcrypt = require('bcryptjs');
        const user = this.config.users.find(u => u.username === username);
        
        if (!user) {
            return null;
        }

        const isValid = await bcrypt.compare(password, user.password);
        if (!isValid) {
            return null;
        }

        // 返回用户数据（不包含密码）
        const { password: _, ...userWithoutPassword } = user;
        return userWithoutPassword;
    }

    // 文件监控
    setupFileWatcher() {
        try {
            const chokidar = require('chokidar');
            const watcher = chokidar.watch(this.configPath, {
                ignored: /node_modules/,
                persistent: true
            });

            watcher.on('change', async () => {
                console.log('配置文件已更改，重新加载...');
                await this.loadConfig();
                this.notifyWatchers();
            });

            console.log('✅ 配置文件监控已启动');
        } catch (error) {
            console.log('⚠️  文件监控需要安装 chokidar: npm install chokidar');
        }
    }

    // 监听器管理
    addWatcher(name, callback) {
        this.watchers.set(name, callback);
    }

    removeWatcher(name) {
        this.watchers.delete(name);
    }

    notifyWatchers() {
        this.watchers.forEach((callback, name) => {
            try {
                callback(this.config);
            } catch (error) {
                console.error(`监听器 ${name} 执行失败:`, error);
            }
        });

        // 通过Socket.io通知前端
        if (this.io) {
            this.io.emit('configUpdated', this.config);
        }
    }

    // 设置Socket.io实例
    setSocketIO(io) {
        this.io = io;
    }

    // 工具函数
    generateId() {
        return 'id_' + Date.now() + '_' + Math.random().toString(36).substring(2, 15);
    }

    // 备份配置
    async backupConfig() {
        const backupPath = this.configPath + '.backup.' + Date.now();
        try {
            await fs.copyFile(this.configPath, backupPath);
            console.log('✅ 配置文件已备份到:', backupPath);
        } catch (error) {
            console.error('备份配置文件失败:', error);
        }
    }

    // 恢复配置
    async restoreConfig(backupPath) {
        try {
            await fs.copyFile(backupPath, this.configPath);
            await this.loadConfig();
            console.log('✅ 配置文件已恢复');
        } catch (error) {
            console.error('恢复配置文件失败:', error);
            throw error;
        }
    }

    // 验证配置
    validateConfig() {
        const errors = [];
        
        if (!this.config.server || !this.config.server.jwtSecret) {
            errors.push('缺少服务器JWT密钥');
        }
        
        if (!this.config.minecraft || !this.config.minecraft.host) {
            errors.push('缺少Minecraft服务器地址');
        }
        
        if (!Array.isArray(this.config.presets?.standbyPoints)) {
            errors.push('待机点配置格式错误');
        }
        
        if (!Array.isArray(this.config.presets?.trapdoorPoints)) {
            errors.push('活板门点配置格式错误');
        }
        
        if (!Array.isArray(this.config.users) || this.config.users.length === 0) {
            errors.push('用户配置错误');
        }
        
        return errors;
    }
}

module.exports = ConfigManager;