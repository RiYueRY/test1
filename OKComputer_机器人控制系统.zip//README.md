# Mineflayer 机器人控制系统

一个基于Web的Mineflayer机器人控制面板，具有安全的登录认证和实时状态监控功能。

## 功能特性

### 🔐 安全认证
- 强制登录验证，防止未授权访问
- JWT令牌管理
- 会话超时保护

### 🤖 机器人控制
- 实时状态监控（位置、生命值、饥饿值）
- 自动导航到指定坐标
- 活板门自动识别和使用
- 任务执行和返回待机点

### 📍 预设点管理
- 添加/编辑/删除多个预设点
- 支持活板门和待机点两种类型
- 坐标精确管理

### 📊 实时监控
- 实时日志显示
- 任务进度跟踪
- 在线玩家列表
- 连接状态监控

### 🎨 现代化界面
- 响应式设计，支持移动端
- 科技感玻璃拟态界面
- 流畅的动画效果
- 实时数据可视化

## 技术架构

- **前端**: HTML5 + CSS3 + JavaScript (Tailwind CSS)
- **后端**: Node.js + Express.js
- **实时通信**: Socket.io
- **Minecraft集成**: Mineflayer
- **身份验证**: JWT
- **数据可视化**: ECharts

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置环境

编辑 `.env` 文件：

```env
PORT=3000
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
NODE_ENV=development

# Minecraft 服务器配置（可选）
ENABLE_BOT=false
MINECRAFT_HOST=localhost
MINECRAFT_PORT=25565
MINECRAFT_USERNAME=WebRobot
MINECRAFT_VERSION=1.20.1
```

### 3. 启动系统

```bash
# 开发模式
npm run dev

# 生产模式
npm start
```

### 4. 访问控制面板

打开浏览器访问：`http://localhost:3000`

- 默认用户名：`admin`
- 默认密码：`password`

## 使用说明

### 连接机器人

1. 确保Minecraft服务器正在运行
2. 在系统设置中配置服务器地址和端口
3. 将 `ENABLE_BOT` 设置为 `true`
4. 重启系统

### 创建预设点

1. 进入"预设点管理"页面
2. 点击"添加预设点"按钮
3. 填写名称、坐标和类型
4. 保存预设点

### 执行任务

1. 在控制面板中选择目标活板门
2. 选择返回待机点
3. 点击"开始任务"按钮
4. 监控任务执行状态

### 安全建议

1. **修改默认密码**：首次登录后立即修改默认密码
2. **更改JWT密钥**：在生产环境中使用强随机密钥
3. **限制访问**：配置防火墙限制访问IP
4. **使用HTTPS**：在生产环境中启用HTTPS

## API 接口

### 认证接口

- `POST /api/login` - 用户登录
- `GET /api/verify` - 验证令牌

### 机器人控制

- `GET /api/bot-status` - 获取机器人状态
- `POST /api/task/start` - 开始任务
- `POST /api/task/stop` - 停止任务

### 预设点管理

- `GET /api/presets` - 获取所有预设点
- `POST /api/presets` - 添加预设点
- `PUT /api/presets/:id` - 更新预设点
- `DELETE /api/presets/:id` - 删除预设点

### WebSocket 事件

- `botStatusUpdated` - 机器人状态更新
- `presetsUpdated` - 预设点更新
- `taskStarted` - 任务开始
- `taskStopped` - 任务停止

## 自定义配置

### 修改默认用户

在 `server.js` 中修改用户配置：

```javascript
const users = [
  {
    id: '1',
    username: 'your-username',
    password: '$2a$10$...' // 使用 bcrypt 加密的密码
  }
];
```

### 添加更多机器人功能

在 `bot.js` 中扩展 `MinecraftBot` 类：

```javascript
async function newFunction() {
  // 添加新的机器人功能
}
```

### 自定义界面主题

在 `dashboard.html` 中修改 CSS 变量：

```css
:root {
  --primary-color: #ff6b35;
  --secondary-color: #16213e;
  --background-color: #0f0f23;
}
```

## 故障排除

### 机器人无法连接

1. 检查Minecraft服务器状态
2. 验证服务器地址和端口
3. 确保游戏版本匹配
4. 检查防火墙设置

### 认证失败

1. 验证用户名和密码
2. 检查JWT密钥配置
3. 清除浏览器缓存
4. 检查令牌有效期

### 任务执行失败

1. 检查预设点坐标
2. 验证路径是否可达
3. 检查机器人状态
4. 查看实时日志

## 开发计划

- [ ] 多机器人管理
- [ ] 任务队列系统
- [ ] 高级路径规划
- [ ] 插件系统
- [ ] 数据持久化
- [ ] 用户权限管理
- [ ] 任务调度器
- [ ] 统计分析

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request来改进这个项目！

## 联系方式

如有问题或建议，请通过以下方式联系：

- 提交 Issue
- 发送邮件
- 加入讨论组

---

**注意**: 请确保在使用此系统时遵守Minecraft服务器的相关规定和法律法规。