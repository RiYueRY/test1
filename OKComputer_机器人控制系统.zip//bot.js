const mineflayer = require('mineflayer');
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');

class MinecraftBot {
    constructor() {
        this.bot = null;
        this.isConnected = false;
        this.currentTask = null;
        this.targetPosition = null;
        this.standbyPosition = null;
    }

    createBot(options = {}) {
        const defaultOptions = {
            host: 'localhost',
            port: 25565,
            username: 'Robot_' + Math.floor(Math.random() * 1000),
            version: '1.20.1'
        };

        const botOptions = { ...defaultOptions, ...options };
        
        this.bot = mineflayer.createBot(botOptions);
        
        // 加载路径查找插件
        this.bot.loadPlugin(pathfinder);
        
        this.setupEventListeners();
        
        return this.bot;
    }

    setupEventListeners() {
        this.bot.on('spawn', () => {
            console.log('机器人已连接到服务器');
            this.isConnected = true;
            
            // 设置默认移动
            const mcData = require('minecraft-data')(this.bot.version);
            const movements = new Movements(this.bot, mcData);
            this.bot.pathfinder.setMovements(movements);
        });

        this.bot.on('end', () => {
            console.log('机器人已断开连接');
            this.isConnected = false;
        });

        this.bot.on('error', (error) => {
            console.error('机器人错误:', error);
            this.isConnected = false;
        });

        this.bot.on('death', () => {
            console.log('机器人死亡');
            this.currentTask = null;
        });

        // 监听聊天消息（用于调试）
        this.bot.on('chat', (username, message) => {
            if (username === this.bot.username) return;
            
            console.log(`[${username}] ${message}`);
            
            // 简单的命令处理
            if (message.startsWith('!')) {
                this.handleCommand(username, message.slice(1));
            }
        });
    }

    async handleCommand(username, command) {
        const args = command.split(' ');
        
        switch (args[0].toLowerCase()) {
            case 'come':
                // 前往玩家位置
                const player = this.bot.players[username];
                if (player && player.entity) {
                    await this.navigateTo(player.entity.position);
                    this.bot.chat(`正在前往 ${username} 的位置`);
                }
                break;
                
            case 'goto':
                // 前往指定坐标
                if (args.length >= 4) {
                    const x = parseInt(args[1]);
                    const y = parseInt(args[2]);
                    const z = parseInt(args[3]);
                    
                    if (!isNaN(x) && !isNaN(y) && !isNaN(z)) {
                        await this.navigateTo({ x, y, z });
                        this.bot.chat(`正在前往坐标 ${x} ${y} ${z}`);
                    }
                }
                break;
                
            case 'trapdoor':
                // 寻找并使用附近的活板门
                await this.findAndUseTrapdoor();
                break;
                
            case 'status':
                // 显示状态
                const pos = this.bot.entity.position;
                this.bot.chat(`位置: ${Math.round(pos.x)} ${Math.round(pos.y)} ${Math.round(pos.z)}`);
                break;
        }
    }

    async navigateTo(position) {
        if (!this.isConnected) {
            throw new Error('机器人未连接');
        }

        return new Promise((resolve, reject) => {
            const goal = new goals.GoalBlock(position.x, position.y, position.z);
            this.bot.pathfinder.setGoal(goal);
            
            const onGoalReached = () => {
                this.bot.pathfinder.removeListener('goal_reached', onGoalReached);
                this.bot.pathfinder.removeListener('path_update', onPathUpdate);
                resolve();
            };
            
            const onPathUpdate = (results) => {
                if (results.status === 'noPath') {
                    this.bot.pathfinder.removeListener('goal_reached', onGoalReached);
                    this.bot.pathfinder.removeListener('path_update', onPathUpdate);
                    reject(new Error('无法找到路径'));
                }
            };
            
            this.bot.pathfinder.on('goal_reached', onGoalReached);
            this.bot.pathfinder.on('path_update', onPathUpdate);
            
            // 设置超时
            setTimeout(() => {
                this.bot.pathfinder.removeListener('goal_reached', onGoalReached);
                this.bot.pathfinder.removeListener('path_update', onPathUpdate);
                reject(new Error('导航超时'));
            }, 60000); // 60秒超时
        });
    }

    async findAndUseTrapdoor() {
        if (!this.isConnected) {
            throw new Error('机器人未连接');
        }

        // 寻找附近的活板门
        const trapdoors = this.bot.findBlocks({
            matching: (block) => {
                return block.name && block.name.includes('trapdoor');
            },
            maxDistance: 16,
            count: 10
        });

        if (trapdoors.length === 0) {
            this.bot.chat('附近没有找到活板门');
            return false;
        }

        // 选择最近的活板门
        const nearestTrapdoor = trapdoors[0];
        const trapdoorBlock = this.bot.blockAt(nearestTrapdoor);
        
        if (!trapdoorBlock) {
            this.bot.chat('无法访问活板门');
            return false;
        }

        // 前往活板门
        this.bot.chat('发现活板门，正在前往...');
        await this.navigateTo(nearestTrapdoor);
        
        // 等待一下确保到达
        await this.sleep(1000);
        
        // 使用活板门（右键点击）
        try {
            await this.bot.activateBlock(trapdoorBlock);
            this.bot.chat('已成功使用活板门');
            return true;
        } catch (error) {
            console.error('使用活板门失败:', error);
            this.bot.chat('使用活板门失败');
            return false;
        }
    }

    async executeTask(trapdoorPos, standbyPos) {
        if (this.currentTask) {
            throw new Error('已有任务正在执行');
        }

        this.currentTask = {
            status: 'running',
            trapdoor: trapdoorPos,
            standby: standbyPos,
            startedAt: new Date()
        };

        try {
            // 第一步：前往活板门
            this.bot.chat(`开始任务：前往 ${trapdoorPos.name}`);
            await this.navigateTo({ x: trapdoorPos.x, y: trapdoorPos.y, z: trapdoorPos.z });
            
            // 第二步：使用活板门
            await this.sleep(1000);
            const trapdoorBlock = this.bot.blockAt({ x: trapdoorPos.x, y: trapdoorPos.y, z: trapdoorPos.z });
            if (trapdoorBlock && trapdoorBlock.name.includes('trapdoor')) {
                await this.bot.activateBlock(trapdoorBlock);
                this.bot.chat('已使用活板门');
            }
            
            // 第三步：返回待机点
            await this.sleep(1000);
            this.bot.chat(`返回待机点 ${standbyPos.name}`);
            await this.navigateTo({ x: standbyPos.x, y: standbyPos.y, z: standbyPos.z });
            
            this.bot.chat('任务完成！');
            this.currentTask = null;
            return true;
            
        } catch (error) {
            console.error('任务执行失败:', error);
            this.bot.chat(`任务失败: ${error.message}`);
            this.currentTask = null;
            throw error;
        }
    }

    stopTask() {
        if (this.currentTask) {
            this.currentTask = null;
            this.bot.pathfinder.setGoal(null);
            this.bot.chat('任务已停止');
            return true;
        }
        return false;
    }

    getStatus() {
        if (!this.isConnected || !this.bot.entity) {
            return {
                connected: false,
                position: { x: 0, y: 0, z: 0 },
                health: 0,
                food: 0,
                currentTask: this.currentTask,
                players: []
            };
        }

        const pos = this.bot.entity.position;
        const health = this.bot.health || 20;
        const food = this.bot.food || 20;
        
        // 获取在线玩家列表
        const players = Object.values(this.bot.players)
            .filter(player => player.username !== this.bot.username && player.entity)
            .map(player => ({
                username: player.username,
                position: player.entity ? {
                    x: Math.round(player.entity.position.x),
                    y: Math.round(player.entity.position.y),
                    z: Math.round(player.entity.position.z)
                } : null
            }));

        return {
            connected: this.isConnected,
            position: {
                x: Math.round(pos.x),
                y: Math.round(pos.y),
                z: Math.round(pos.z)
            },
            health: Math.round(health),
            food: Math.round(food),
            currentTask: this.currentTask,
            players: players
        };
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    disconnect() {
        if (this.bot) {
            this.bot.quit();
            this.isConnected = false;
        }
    }
}

module.exports = MinecraftBot;