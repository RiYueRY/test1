const mineflayer = require('mineflayer');
const { pathfinder, Movements, goals } = require('mineflayer-pathfinder');
const fs = require('fs').promises;
const path = require('path');

class EnhancedMinecraftBot {
    constructor(configManager) {
        this.configManager = configManager;
        this.bot = null;
        this.isConnected = false;
        this.isConnecting = false;
        this.currentTask = null;
        this.reconnectAttempts = 0;
        this.lastDisconnectTime = null;
        this.chatQueue = [];
        this.isProcessingChat = false;
        this.taskQueue = [];
        this.isProcessingTask = false;
        
        // 状态缓存
        this.statusCache = {
            position: { x: 0, y: 0, z: 0 },
            health: 20,
            food: 20,
            players: [],
            lastUpdate: Date.now()
        };
    }

    async createBot() {
        if (this.isConnecting) {
            console.log('机器人正在连接中...');
            return null;
        }

        const config = this.configManager.getConfig();
        const botConfig = config.minecraft;
        
        this.isConnecting = true;
        
        try {
            const botOptions = {
                host: botConfig.host,
                port: botConfig.port,
                username: botConfig.username,
                version: botConfig.version,
                auth: botConfig.auth
            };

            // 如果需要密码
            if (botConfig.password) {
                botOptions.password = botConfig.password;
            }

            console.log(`正在连接到Minecraft服务器: ${botConfig.host}:${botConfig.port}`);
            console.log(`用户名: ${botConfig.username}`);
            console.log(`认证方式: ${botConfig.auth}`);

            this.bot = mineflayer.createBot(botOptions);
            
            // 加载插件
            this.bot.loadPlugin(pathfinder);
            
            this.setupEventListeners();
            
            return this.bot;
            
        } catch (error) {
            console.error('创建机器人失败:', error);
            this.isConnecting = false;
            throw error;
        }
    }

    setupEventListeners() {
        // 成功连接
        this.bot.on('spawn', async () => {
            console.log('🎉 机器人成功连接到服务器');
            this.isConnected = true;
            this.isConnecting = false;
            this.reconnectAttempts = 0;
            this.lastDisconnectTime = null;
            
            // 设置默认移动
            const mcData = require('minecraft-data')(this.bot.version);
            const movements = new Movements(this.bot, mcData);
            this.bot.pathfinder.setMovements(movements);
            
            // 延迟执行初始化操作
            setTimeout(() => {
                this.handlePostSpawn();
            }, 2000);
            
            this.emitStatusUpdate();
        });

        // 断开连接
        this.bot.on('end', (reason) => {
            console.log(`⚠️  机器人断开连接: ${reason}`);
            this.isConnected = false;
            this.isConnecting = false;
            this.lastDisconnectTime = Date.now();
            this.currentTask = null;
            
            this.emitStatusUpdate();
            
            // 自动重连
            this.scheduleReconnect();
        });

        // 错误处理
        this.bot.on('error', (error) => {
            console.error('❌ 机器人错误:', error);
            this.isConnected = false;
            this.isConnecting = false;
            this.emitStatusUpdate();
        });

        // 被踢出服务器
        this.bot.on('kicked', (reason) => {
            console.log(`🚫 机器人被踢出: ${reason}`);
            this.isConnected = false;
            this.lastDisconnectTime = Date.now();
            this.emitStatusUpdate();
            
            // 延迟重连，避免频繁重连
            setTimeout(() => {
                this.scheduleReconnect();
            }, 10000);
        });

        // 死亡处理
        this.bot.on('death', () => {
            console.log('💀 机器人死亡');
            this.stopCurrentTask();
            this.emitStatusUpdate();
            
            // 延迟重生
            setTimeout(() => {
                if (this.bot.isDead) {
                    this.bot.respawn();
                }
            }, 3000);
        });

        // 聊天消息处理
        this.bot.on('chat', (username, message) => {
            if (username === this.bot.username) return;
            
            console.log(`[${username}] ${message}`);
            this.handleChatMessage(username, message);
        });

        // 登录插件处理
        this.bot.on('message', (message) => {
            const msgText = message.toString();
            console.log('收到消息:', msgText);
            
            // 处理登录/注册提示
            this.handleServerMessage(msgText);
        });

        // 状态更新
        this.bot.on('health', () => {
            this.updateStatusCache();
            this.emitStatusUpdate();
        });

        this.bot.on('food', () => {
            this.updateStatusCache();
            this.emitStatusUpdate();
        });

        // 移动相关事件
        this.bot.pathfinder.on('goal_reached', () => {
            console.log('✅ 到达目的地');
            this.processNextTask();
        });

        this.bot.pathfinder.on('path_update', (results) => {
            if (results.status === 'noPath') {
                console.log('❌ 无法找到路径');
                this.handlePathfindingError();
            }
        });
    }

    async handlePostSpawn() {
        const config = this.configManager.getConfig();
        
        // 处理登录插件
        if (config.minecraft.loginCommands.enabled) {
            setTimeout(() => {
                this.handleLoginPlugin();
            }, 3000);
        }
        
        // 发送欢迎消息
        setTimeout(() => {
            this.sayHello();
        }, 5000);
    }

    async handleLoginPlugin() {
        const config = this.configManager.getConfig();
        const loginConfig = config.minecraft.loginCommands;
        
        if (!loginConfig.enabled) return;
        
        console.log('处理登录插件...');
        
        // 等待服务器提示
        await this.sleep(2000);
        
        // 尝试注册（如果是第一次）
        const registerCmd = loginConfig.registerCommand.replace(/{password}/g, loginConfig.password);
        this.bot.chat(registerCmd);
        
        // 等待一下再登录
        await this.sleep(2000);
        
        // 登录
        const loginCmd = loginConfig.loginCommand.replace(/{password}/g, loginConfig.password);
        this.bot.chat(loginCmd);
    }

    handleServerMessage(message) {
        const lowerMsg = message.toLowerCase();
        
        // 检测登录提示
        if (lowerMsg.includes('login') || lowerMsg.includes('register') || 
            lowerMsg.includes('密码') || lowerMsg.includes('password')) {
            
            const config = this.configManager.getConfig();
            if (config.minecraft.loginCommands.enabled) {
                setTimeout(() => {
                    this.handleLoginPlugin();
                }, 1000);
            }
        }
        
        // 检测被攻击
        if (lowerMsg.includes('attack') || lowerMsg.includes('hurt') || 
            lowerMsg.includes('damage') || lowerMsg.includes('伤害')) {
            
            console.log('⚠️  机器人可能受到攻击');
            // 可以添加逃跑逻辑
        }
    }

    sayHello() {
        const messages = [
            '大家好！我是WebRobot 🤖',
            '机器人已上线，准备执行任务！',
            'Hello! I am WebRobot, ready for tasks!'
        ];
        
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        this.bot.chat(randomMessage);
    }

    scheduleReconnect() {
        const config = this.configManager.getConfig();
        const maxAttempts = config.minecraft.maxReconnectAttempts;
        
        if (this.reconnectAttempts >= maxAttempts) {
            console.log(`已达到最大重连次数 (${maxAttempts})，停止重连`);
            return;
        }
        
        this.reconnectAttempts++;
        const delay = config.minecraft.reconnectDelay * this.reconnectAttempts;
        
        console.log(`⏰ ${delay/1000}秒后进行第 ${this.reconnectAttempts} 次重连...`);
        
        setTimeout(() => {
            if (!this.isConnected && !this.isConnecting) {
                console.log('🔄 尝试重新连接...');
                this.createBot().catch(error => {
                    console.error('重连失败:', error);
                });
            }
        }, delay);
    }

    // 导航功能
    async navigateTo(position, timeout = 60000) {
        if (!this.isConnected || !this.bot.entity) {
            throw new Error('机器人未连接');
        }

        const config = this.configManager.getConfig();
        const arrivalDistance = config.robot.movement.arrivalDistance;
        
        return new Promise((resolve, reject) => {
            const goal = new goals.GoalNear(
                position.x, 
                position.y, 
                position.z, 
                arrivalDistance
            );
            
            this.bot.pathfinder.setGoal(goal);
            
            let timeoutId = setTimeout(() => {
                this.bot.pathfinder.setGoal(null);
                reject(new Error('导航超时'));
            }, timeout);
            
            const checkArrival = () => {
                const currentPos = this.bot.entity.position;
                const distance = Math.sqrt(
                    Math.pow(currentPos.x - position.x, 2) +
                    Math.pow(currentPos.y - position.y, 2) +
                    Math.pow(currentPos.z - position.z, 2)
                );
                
                if (distance <= arrivalDistance) {
                    clearTimeout(timeoutId);
                    this.bot.pathfinder.setGoal(null);
                    resolve();
                } else {
                    setTimeout(checkArrival, 1000);
                }
            };
            
            setTimeout(checkArrival, 2000);
        });
    }

    // 寻找并使用活板门
    async findAndUseTrapdoor(trapdoorPos = null) {
        if (!this.isConnected) {
            throw new Error('机器人未连接');
        }

        let trapdoorBlock = null;
        
        // 如果提供了具体位置，直接查找该位置的活板门
        if (trapdoorPos) {
            trapdoorBlock = this.bot.blockAt({
                x: trapdoorPos.x,
                y: trapdoorPos.y,
                z: trapdoorPos.z
            });
            
            if (!trapdoorBlock || !trapdoorBlock.name.includes('trapdoor')) {
                throw new Error('指定位置没有找到活板门');
            }
        } else {
            // 搜索附近的活板门
            const trapdoors = this.bot.findBlocks({
                matching: (block) => {
                    return block.name && block.name.includes('trapdoor');
                },
                maxDistance: 16,
                count: 10
            });

            if (trapdoors.length === 0) {
                throw new Error('附近没有找到活板门');
            }

            trapdoorBlock = this.bot.blockAt(trapdoors[0]);
        }
        
        if (!trapdoorBlock) {
            throw new Error('无法访问活板门');
        }

        // 前往活板门位置
        const trapdoorPos = trapdoorBlock.position;
        console.log(`前往活板门位置: ${trapdoorPos.x}, ${trapdoorPos.y}, ${trapdoorPos.z}`);
        
        await this.navigateTo(trapdoorPos);
        
        // 等待到达
        await this.sleep(1000);
        
        // 使用活板门
        try {
            await this.bot.activateBlock(trapdoorBlock);
            console.log('✅ 成功使用活板门');
            return true;
        } catch (error) {
            console.error('使用活板门失败:', error);
            throw new Error('使用活板门失败');
        }
    }

    // 执行任务
    async executeTask(trapdoorId, standbyId) {
        if (this.currentTask) {
            throw new Error('已有任务正在执行');
        }

        const config = this.configManager.getConfig();
        const trapdoor = config.presets.trapdoorPoints.find(p => p.id === trapdoorId);
        const standby = config.presets.standbyPoints.find(p => p.id === standbyId);
        
        if (!trapdoor || !standby) {
            throw new Error('预设点不存在');
        }

        this.currentTask = {
            id: uuidv4(),
            status: 'running',
            trapdoor,
            standby,
            startedAt: new Date(),
            steps: [
                { name: '前往活板门', status: 'pending' },
                { name: '使用活板门', status: 'pending' },
                { name: '返回待机点', status: 'pending' }
            ]
        };

        try {
            // 第一步：前往活板门
            this.currentTask.steps[0].status = 'running';
            this.bot.chat(`开始任务：前往 ${trapdoor.name}`);
            
            await this.navigateTo({ x: trapdoor.x, y: trapdoor.y, z: trapdoor.z });
            this.currentTask.steps[0].status = 'completed';
            
            // 第二步：使用活板门
            this.currentTask.steps[1].status = 'running';
            await this.sleep(1000);
            
            const trapdoorUsed = await this.findAndUseTrapdoor(trapdoor);
            if (trapdoorUsed) {
                this.bot.chat('已成功使用活板门');
                this.currentTask.steps[1].status = 'completed';
            } else {
                throw new Error('无法使用活板门');
            }
            
            // 第三步：返回待机点
            this.currentTask.steps[2].status = 'running';
            await this.sleep(1000);
            
            this.bot.chat(`返回待机点 ${standby.name}`);
            await this.navigateTo({ x: standby.x, y: standby.y, z: standby.z });
            this.currentTask.steps[2].status = 'completed';
            
            // 任务完成
            this.bot.chat('任务完成！✅');
            this.currentTask.status = 'completed';
            this.currentTask.endedAt = new Date();
            
            // 延迟清理任务
            setTimeout(() => {
                this.currentTask = null;
            }, 2000);
            
            return true;
            
        } catch (error) {
            console.error('任务执行失败:', error);
            
            this.bot.chat(`任务失败: ${error.message}`);
            this.currentTask.status = 'failed';
            this.currentTask.error = error.message;
            this.currentTask.endedAt = new Date();
            
            // 尝试返回待机点
            try {
                this.bot.chat('尝试返回待机点...');
                await this.navigateTo({ x: standby.x, y: standby.y, z: standby.z });
            } catch (returnError) {
                console.error('返回待机点失败:', returnError);
            }
            
            setTimeout(() => {
                this.currentTask = null;
            }, 5000);
            
            throw error;
        }
    }

    stopCurrentTask() {
        if (this.currentTask) {
            this.currentTask.status = 'stopped';
            this.currentTask.endedAt = new Date();
            
            if (this.bot && this.bot.pathfinder) {
                this.bot.pathfinder.setGoal(null);
            }
            
            this.currentTask = null;
            return true;
        }
        return false;
    }

    // 聊天处理
    handleChatMessage(username, message) {
        const lowerMsg = message.toLowerCase();
        
        // 简单命令处理
        if (lowerMsg.startsWith('!')) {
            const command = lowerMsg.slice(1).trim();
            this.handleCommand(username, command);
        }
        
        // 添加到聊天队列
        this.chatQueue.push({
            username,
            message,
            timestamp: Date.now()
        });
        
        // 限制队列大小
        if (this.chatQueue.length > 50) {
            this.chatQueue.shift();
        }
    }

    async handleCommand(username, command) {
        const args = command.split(' ');
        
        switch (args[0]) {
            case 'help':
                this.bot.chat('可用命令: !come, !goto x y z, !status, !stop');
                break;
                
            case 'come':
                const player = this.bot.players[username];
                if (player && player.entity) {
                    this.bot.chat(`正在前往 ${username} 的位置`);
                    await this.navigateTo(player.entity.position);
                } else {
                    this.bot.chat(`找不到玩家 ${username}`);
                }
                break;
                
            case 'goto':
                if (args.length >= 4) {
                    const x = parseInt(args[1]);
                    const y = parseInt(args[2]);
                    const z = parseInt(args[3]);
                    
                    if (!isNaN(x) && !isNaN(y) && !isNaN(z)) {
                        this.bot.chat(`正在前往坐标 ${x} ${y} ${z}`);
                        await this.navigateTo({ x, y, z });
                    } else {
                        this.bot.chat('坐标格式错误，使用: !goto x y z');
                    }
                } else {
                    this.bot.chat('用法: !goto x y z');
                }
                break;
                
            case 'status':
                const status = this.getStatus();
                this.bot.chat(`状态: ${status.connected ? '在线' : '离线'}, 位置: ${status.position.x} ${status.position.y} ${status.position.z}`);
                break;
                
            case 'stop':
                if (this.stopCurrentTask()) {
                    this.bot.chat('任务已停止');
                } else {
                    this.bot.chat('没有正在执行的任务');
                }
                break;
        }
    }

    // 状态管理
    updateStatusCache() {
        if (!this.isConnected || !this.bot.entity) {
            this.statusCache = {
                position: { x: 0, y: 0, z: 0 },
                health: 0,
                food: 0,
                players: [],
                lastUpdate: Date.now()
            };
            return;
        }

        const pos = this.bot.entity.position;
        const health = this.bot.health || 20;
        const food = this.bot.food || 20;
        
        // 获取在线玩家
        const players = Object.values(this.bot.players)
            .filter(player => player.username !== this.bot.username && player.entity)
            .map(player => ({
                username: player.username,
                position: player.entity ? {
                    x: Math.round(player.entity.position.x),
                    y: Math.round(player.entity.position.y),
                    z: Math.round(player.entity.position.z)
                } : null
            }));

        this.statusCache = {
            connected: this.isConnected,
            position: {
                x: Math.round(pos.x),
                y: Math.round(pos.y),
                z: Math.round(pos.z)
            },
            health: Math.round(health),
            food: Math.round(food),
            currentTask: this.currentTask,
            players: players,
            lastUpdate: Date.now()
        };
    }

    getStatus() {
        this.updateStatusCache();
        return this.statusCache;
    }

    emitStatusUpdate() {
        if (this.configManager.io) {
            this.configManager.io.emit('botStatusUpdated', this.getStatus());
        }
    }

    handlePathfindingError() {
        console.log('路径查找失败，尝试清理路径...');
        if (this.bot.pathfinder) {
            this.bot.pathfinder.setGoal(null);
        }
        
        // 如果正在执行任务，标记为失败
        if (this.currentTask) {
            this.currentTask.status = 'failed';
            this.currentTask.error = '无法找到路径';
        }
    }

    // 工具函数
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    disconnect() {
        if (this.bot) {
            this.stopCurrentTask();
            this.bot.quit();
            this.isConnected = false;
            console.log('机器人已断开连接');
        }
    }

    // 发送消息到游戏
    chat(message) {
        if (this.isConnected && this.bot) {
            this.bot.chat(message);
        }
    }
}

module.exports = EnhancedMinecraftBot;