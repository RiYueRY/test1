#!/bin/bash
# 检查是否安装了 python3-pip
if ! command -v pip3 &> /dev/null
then
    echo "pip3 未安装，正在尝试安装..."
    sudo apt-get update && sudo apt-get install -y python3-pip
fi

# 安装依赖
echo "正在安装依赖库..."
pip3 install -r requirements.txt

# 启动服务
echo "正在启动 4399 API 服务..."
python3 4399Register.py
