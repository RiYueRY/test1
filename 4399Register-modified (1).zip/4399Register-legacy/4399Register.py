# -*- coding: utf-8 -*-
import json
import os
import random
from requests import get, post
from random import sample, choice
from ddddocr import DdddOcr
from time import time
from string import ascii_letters, digits, ascii_lowercase
from logging import getLogger, StreamHandler, Formatter, INFO
from fastapi import FastAPI
import uvicorn

# 加载配置
CONFIG_PATH = "config.json"
def load_config():
    if not os.path.exists(CONFIG_PATH):
        default_config = {
            "apikey": "1d9f8fd58e2d9f24044805c2af2f7811229b8c5f2db5ff36f5eda7bb40ec1c53",
            "sfz_api_url": "https://www.yx520.ltd/API/sjsfz/api.php",
            "port": 5000,
            "host": "0.0.0.0",
            "proxy": {
                "mode": "none",
                "api_url": "",
                "file_path": "proxies.txt"
            }
        }
        with open(CONFIG_PATH, "w") as f:
            json.dump(default_config, f, indent=4)
        return default_config
    else:
        with open(CONFIG_PATH, "r") as f:
            return json.load(f)

config = load_config()

strings = ascii_letters + digits
captcha_strings = ascii_lowercase + digits

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36'
}

log = getLogger()
log.setLevel(INFO)
console_handler = StreamHandler()
console_handler.setLevel(INFO)
formatter = Formatter('[%(asctime)s %(levelname)s] %(message)s', datefmt='%Y-%m-%d %H:%M:%S')
console_handler.setFormatter(formatter)
log.addHandler(console_handler)

# 初始化 OCR
ocr = DdddOcr(use_gpu=False, show_ad=False, import_onnx_path="4399ocr/4399ocr.onnx",
              charsets_path="4399ocr/4399ocr.json")

def randstr(chars, length):
    return ''.join(sample(chars, length))

def time_how(start):
    return f"{(time() - start):.2f}"

def get_proxy():
    proxy_cfg = config.get("proxy", {})
    mode = proxy_cfg.get("mode", "none").lower()
    
    if mode == "none" or not mode:
        return None
    
    if mode == "api":
        api_url = proxy_cfg.get("api_url")
        if api_url:
            try:
                res = get(api_url, timeout=5)
                proxy_str = res.text.strip()
                if proxy_str:
                    return {"http": f"http://{proxy_str}", "https": f"http://{proxy_str}"}
            except Exception as e:
                log.error(f"从 API 获取代理失败: {e}")
    
    if mode == "file":
        file_path = proxy_cfg.get("file_path", "proxies.txt")
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r') as f:
                    lines = [line.strip() for line in f if line.strip()]
                    if lines:
                        proxy_str = choice(lines)
                        return {"http": f"http://{proxy_str}", "https": f"http://{proxy_str}"}
            except Exception as e:
                log.error(f"从文件读取代理失败: {e}")
                
    return None

def get_random_sfz():
    try:
        url = f"{config['sfz_api_url']}?apikey={config['apikey']}"
        response = get(url, headers=headers, timeout=10)
        # 接口返回格式示例: 赵云----220122198902230712
        text = response.text.strip()
        if "----" in text:
            name, idcard = text.split("----")
            return name, idcard
        else:
            log.error(f"获取身份证失败，返回内容: {text}")
            return None, None
    except Exception as e:
        log.error(f"请求身份证 API 出错: {e}")
        return None, None

def register_4399(usr, pwd):
    start = time()
    name, idcard = get_random_sfz()
    if not name or not idcard:
        return {"status": "error", "message": "无法获取有效的身份证信息"}

    proxies = get_proxy()
    if proxies:
        log.info(f"使用代理: {proxies['http']}")
    
    log.info(f"使用身份证: {name}:{idcard}")

    sessionId = 'captchaReq' + randstr(captcha_strings, 19)
    try:
        captcha_response = get(
            f'https://ptlogin.4399.com/ptlogin/captcha.do?captchaId={sessionId}',
            headers=headers,
            proxies=proxies,
            verify=False,
            timeout=10
        ).content
        captcha = ocr.classification(captcha_response)
        log.info(f"验证码识别结果: {captcha}")

        data = {
            'postLoginHandler': 'default',
            'displayMode': 'popup',
            'appId': 'www_home',
            'gameId': '',
            'cid': '',
            'externalLogin': 'qq',
            'aid': '',
            'ref': '',
            'css': '',
            'redirectUrl': '',
            'regMode': 'reg_normal',
            'sessionId': sessionId,
            'regIdcard': 'true',
            'noEmail': '',
            'crossDomainIFrame': '',
            'crossDomainUrl': '',
            'mainDivId': 'popup_reg_div',
            'showRegInfo': 'true',
            'includeFcmInfo': 'false',
            'expandFcmInput': 'true',
            'fcmFakeValidate': 'false',
            'realnameValidate': 'true',
            'username': usr,
            'password': pwd,
            'passwordveri': pwd,
            'email': '',
            'inputCaptcha': captcha,
            'reg_eula_agree': 'on',
            'realname': name,
            'idcard': idcard
        }

        response_text = post(
            'https://ptlogin.4399.com/ptlogin/register.do',
            data=data,
            proxies=proxies,
            headers=headers,
            verify=False,
            timeout=10
        ).text

        if '注册成功' in response_text:
            log.info(f"注册成功: {usr}:{pwd} (耗时 {time_how(start)}s)")
            return {"status": "success", "username": usr, "password": pwd}
        
        # 定义需要重试的错误情况
        retry_messages = [
            '验证码错误',
            '身份证实名账号数量超过限制',
            '身份证实名过于频繁',
            '该姓名身份证提交验证过于频繁'
        ]
        
        should_retry = False
        reason = "未知原因"
        
        for msg in retry_messages:
            if msg in response_text:
                should_retry = True
                reason = msg
                break
        
        if should_retry:
            log.info(f"注册失败({reason})，正在更换身份证/验证码并重试... (耗时 {time_how(start)}s)")
            return register_4399(usr, pwd) # 递归重试，直到成功
        
        # 其他不可恢复的错误
        msg = "注册失败"
        if '用户名已被注册' in response_text:
            msg = '用户名已被注册'
        
        log.info(f"注册终止: {msg} (耗时 {time_how(start)}s)")
        return {"status": "fail", "message": msg}

    except Exception as e:
        log.error(f"注册过程出错: {e}")
        return {"status": "error", "message": str(e)}

app = FastAPI()

@app.get("/generate")
async def generate_account():
    usr = "S" + randstr(strings, 3) + "K" + randstr(strings, 3) + "Y" + randstr(strings, 3)
    pwd = randstr(strings, 12)
    result = register_4399(usr, pwd)
    return result

if __name__ == "__main__":
    uvicorn.run(app, host=config["host"], port=config["port"])
